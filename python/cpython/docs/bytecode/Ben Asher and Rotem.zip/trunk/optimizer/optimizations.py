#!/usr/bin/python2.4
import new

import Opcode
import Function
import DataDepTree
import DataDepPasses
import Passes
import Inliner
import UnrollXrange
import UnrollForeachList
import UnrollDynamicXrange
import UnrollListToRandomAccess

import ParallelXrange

import DataDepParser

from DataDepPasses import *

def functionOptimize(function,optimizationMethod):
    func = Function.Function(function)
    optimizationMethod(func)
    return func.get_func()


def functionInline(function, remote):
    func = Function.Function(function)
    Inliner.inline_function(func,remote)
    return func.get_func()

def methodInline(method, remote):
    func = Function.Function(method.im_func)
    obj = method.im_self
    Inliner.inline_function(func,remote)
    res = new.instancemethod(func.get_func(),obj,obj.__class__) 
    setattr(obj,method.__name__,res)

def methodOptimize(method, optimizationMethod):
    """
    Perform the optimization on a method of a class. ex: obj.bark , NumericOptimize
    """
    obj = method.im_self
    func = Function.Function(method.im_func)
    optimizationMethod(func)
    res = new.instancemethod(func.get_func(),obj,obj.__class__)
    setattr(obj,method.__name__, res)

def NumericOptimize(func):
    """
    Optimizations that may only be applied to numeric code
    """
    progress("[")

    # this prepares the stage for xrange unroll...
    UnrollListToRandomAccess.unroll_list(func)
    progress("+")
    UnrollDynamicXrange.open_xrange_args(func)
    progress("+")
    UnrollXrange.open_xrange_args(func)
    progress("+")
    UnrollXrange.unroll_xrange(func,4)
    progress("+")
    UnrollDynamicXrange.unroll_xrange(func,4)
    progress("+")
    UnrollForeachList.unroll_list(func)
    progress("+")
    # list of optimization passes to execute
    passes = [DeepAddJoinConstantVisitor(),\
          JoinAddZeroVisitor(),\
          JoinDoubleLoadVisitor(),\
          LevelAddExpVisitor(),\
          ConstMulExtractVisitor(),\
          JoinDeepMultVisitor(),\
          JoinAddSepMullMultVisitor(),\
          JoinMullSepAddMultVisitor(), ConstComperatorInline(),ConstantSubtract()]
    progress("+")

    #TODO - Add a pass that disables if(False)


    ddnl = DataDepParser.DataDependencyNodeList(func.get_oplist())
    progress("+")
    logging.debug("tree before optimize = \n " + str(ddnl))
    progress("+")
    DataDepTree.optimize(ddnl,passes)
    progress("+")
    func.set_oplist(ddnl.to_oplist())
    logging.debug("tree after optimize = \n " + str(ddnl))
    progress("+")
    Passes.cache_global_calls(func)
    progress("+")

    fret =  func.get_func() 
    progress("]\n")
    return fret


def progress(ch = "."):
    import sys
    print ch,
    sys.stdout.flush()
