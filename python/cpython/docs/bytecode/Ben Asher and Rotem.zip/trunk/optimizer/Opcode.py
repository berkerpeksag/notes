#!/usr/bin/python2.4

# python bytecode handling classes
# this file is the base for all of the package. 

import opcode
opmap_cache = {}
def build_opmap_cache_table():
    """
    builds a cache map for quick searching of opcode names from numbers
    """
    global opmap_cache
    for name,num in opcode.opmap.iteritems():
        opmap_cache[num]=name

def op_name_from_int(op_num):
    """
    return an opcode name for a given number. See "import opcode"
    """
    global opmap_cache
    return opmap_cache[op_num]

def int_from_op_name(op_name):
    """
    return the opcode value for an opcode name
    """
    return  opcode.opmap[op_name]

# build the cache map
build_opmap_cache_table()

class OpcodeNotFoundException(Exception): pass
class InvalidOpcodeException(Exception): pass

class Opcode:
    """
    The Opcode object represents a python bytecode object
    """
    def __init__(self,Func,code_num, arg = None):
        """
        C'tor
        Func - a Function object that the opcodes are using
        """
        self.Func = Func
        self.m_op = code_num
        self.m_raw_arg = arg
        self.m_arg = None
        self.m_address = None

    def default(Func,op_name):
        """
        Create a simple opcode from name. such as "NOP"
        """
        op = Opcode(Func,int_from_op_name(op_name),None)
        op.m_address = 0
        return op
    default = staticmethod(default)    

    def clone(self):
        """
        Clones the opcode so it can be modified later
        """
        op = self.__class__(self.Func,self.m_op,self.m_raw_arg)
        op.m_arg = self.m_arg
        op.m_address = self.m_address
        return op

    def name(self):
        """
        Returns the opcode's name. For example 'LOAD_CONST'
        """
        return op_name_from_int(self.m_op)

    def equals(self,op):
        return self.m_arg == op.m_arg and self.m_op == op.m_op
        
    def address(self): 
        """
        Returns the opcode's address. The address is the offset from the
        beginning of the opcode list and is set by the Oplist class
        """
        if self.m_address==None: raise ValueError(self.__class__)
        return self.m_address

    def size(self): return 1 # this is a simple opcode, 1 byte long, no params

    def write(self, int_out_stream): int_out_stream.append(self.m_op)

    def to_string(self): return " " + self.name()

    def process_args(self, oplist): pass # no arguments to process

    def __str__(self):  return self.to_string()

def write_word_to_intstream(int_out_stream,word):
        """
        writes a word as bytes to a stream of bytes
        """
        if (word>65535) or (word<0): raise ValueError(word)
        int_out_stream.append(word%256)
        int_out_stream.append(word/256) 

class TagOpcode(Opcode):
    """
    Represents a Tag or a Label int the python assembler. This is not written
    to actual code.
    """
    def write(self, int_out_stream):pass # nothing to write
    def size(self): return 0
    def name(self): return "TAG"
    
class HaveArgsOpcode(Opcode):
    """
    Represents all simple opcodes that have arguments
    """
    def write(self, int_out_stream):
        int_out_stream.append(self.m_op)
        write_word_to_intstream(int_out_stream, self.m_arg)

    def process_args(self, oplist): self.m_arg = self.m_raw_arg

    def size(self): return 3

    def to_string(self):
            return Opcode.to_string(self) + " --> " + str(self.m_arg)

class LoadConstOpcode(HaveArgsOpcode):    
    """
    The LOAD_CONST opcode
    """
    def write(self, int_out_stream):
        int_out_stream.append(self.m_op)
        arg = self.Func.add_constant(self.m_arg)
        write_word_to_intstream(int_out_stream, arg)

    def process_args(self, oplist):
        """
        It's true parameter is a constant that is taken from the Func
        """
        self.m_arg = self.Func.get_constant(self.m_raw_arg)

    def from_const(Func,const):
        op = LoadConstOpcode(Func,int_from_op_name('LOAD_CONST'),const)
        op.m_arg = op.m_raw_arg
        return op
    from_const = staticmethod(from_const)

class FastOpcode(HaveArgsOpcode):
    """
    Represents opcodes that access local variables, such as STOER_FAST
    """
    def write(self, int_out_stream):
        int_out_stream.append(self.m_op)
        arg = self.Func.add_varname(self.m_arg)
        write_word_to_intstream(int_out_stream, arg)

    def process_args(self, oplist):
        self.m_arg = self.Func.get_varname(self.m_raw_arg)

    def from_store_fast(Func, fast):
        op = StoreFastOpcode(Func,int_from_op_name('STORE_FAST'),fast)
        op.m_arg = op.m_raw_arg
        return op
    from_store_fast = staticmethod(from_store_fast)

    def from_load_fast(Func, fast):
        op = LoadFastOpcode(Func,int_from_op_name('LOAD_FAST'),fast)
        op.m_arg = op.m_raw_arg
        return op
    from_load_fast = staticmethod(from_load_fast)


class DerefOpcode(HaveArgsOpcode):
    """
    Represents opcodes that access closure variables, such as LOAD_DEREF
    """
    def write(self, int_out_stream):
        int_out_stream.append(self.m_op)
        arg = self.Func.add_cellvar(self.m_arg)
        write_word_to_intstream(int_out_stream, arg)

    def process_args(self, oplist):
        self.m_arg = self.Func.get_cellvar(self.m_raw_arg)

    def from_store_deref(Func, deref):
        op = StoreDerefOpcode(Func,int_from_op_name('STORE_DEREF'),deref)
        op.m_arg = op.m_raw_arg
        return op
    from_store_deref = staticmethod(from_store_deref)

    def from_load_deref(Func, deref):
        op = LoadDerefOpcode(Func,int_from_op_name('LOAD_DEREF'),deref)
        op.m_arg = op.m_raw_arg
        return op
    from_load_deref = staticmethod(from_load_deref)


class AttributeOpcode(HaveArgsOpcode):
    """
    Opcodes that implement the store_attribute and friends
    """
    def write(self, int_out_stream):
        int_out_stream.append(self.m_op)
        arg = self.Func.add_name(self.m_arg)
        write_word_to_intstream(int_out_stream, arg)

    def process_args(self, oplist):
        """
        It's true parameter is a 'name' that is taken from the Func
        """
        self.m_arg = self.Func.get_name(self.m_raw_arg)

    def from_load_attr(Func, fast):
        op = LoadFastOpcode(Func,int_from_op_name('LOAD_ATTR'),fast)
        op.m_arg = op.m_raw_arg
        return op
    from_load_attr = staticmethod(from_load_attr)


class GlobalOpcode(HaveArgsOpcode):
    """
    Load global, store global and such
    """
    def write(self, int_out_stream):
        int_out_stream.append(self.m_op)
        arg = self.Func.add_name(self.m_arg)
        write_word_to_intstream(int_out_stream, arg)

    def process_args(self , oplist):        
        """
        It's true parameter is a 'name' that is taken from the Func
        """
        self.m_arg = self.Func.get_name(self.m_raw_arg)

    def from_load_global(Func, glob):
        op = LoadGlobalOpcode(Func,int_from_op_name('LOAD_GLOBAL'),glob)
        op.m_arg = op.m_raw_arg
        return op
    from_load_global = staticmethod(from_load_global)


class RelativeOpcode(HaveArgsOpcode):
    """
    Opcodes that require relative jumps such as JumpIfTrue
    """
    def write(self, int_out_stream):
        int_out_stream.append(self.m_op)
        write_word_to_intstream(int_out_stream, self.m_arg.address() - self.address() - self.size())
        
    def process_args(self,oplist):
        """
        Adds a tag to where this opcode points to
        """
        if (self.m_arg!=None): return # been processed before
        tag = TagOpcode(self.Func,int_from_op_name('NOP'))
        self.m_arg = tag
        oplist.add_tag_after_address(self.m_raw_arg + self.address() + self.size(), tag)

class AbsoluteOpcode(HaveArgsOpcode):
    """
    Opcodes that require absolute jumps, such as JumpAbsolute
    """
    def write(self, int_out_stream):
        int_out_stream.append(self.m_op)
        write_word_to_intstream(int_out_stream, self.m_arg.address())
        
    def process_args(self,oplist):
        """
        Adds a tag to where this opcode points to
        """
        if (self.m_arg!=None): return #has it been processed before?
        tag = TagOpcode(self.Func, int_from_op_name('NOP'))
        self.m_arg = tag
        oplist.add_tag_after_address(self.m_raw_arg, tag)

    def from_jump_absolute(Func, tag):
        op = JumpAbsoluteOpcode(Func,int_from_op_name('JUMP_ABSOLUTE'),tag)
        op.m_arg = op.m_raw_arg
        return op
    from_jump_absolute = staticmethod(from_jump_absolute)


class JumpAbsoluteOpcode(AbsoluteOpcode): pass
class JumpIfTrueOpcode(RelativeOpcode): pass
class JumpIfFalseOpcode(RelativeOpcode): pass
class SetupLoopOpcode(RelativeOpcode): pass
class SetupExceptOpcode(RelativeOpcode): pass
class ForIterOpcode(RelativeOpcode): pass
class LoadFastOpcode(FastOpcode): pass
class LoadDerefOpcode(DerefOpcode): pass
class LoadGlobalOpcode(GlobalOpcode): pass
class StoreGlobalOpcode(GlobalOpcode): pass

class CallFunctionOpcode(HaveArgsOpcode):

    def from_call_function(Func, args):
        op = CallFunctionOpcode(Func,int_from_op_name('CALL_FUNCTION'),args)
        op.m_arg = op.m_raw_arg
        return op
    from_call_function = staticmethod(from_call_function)



class LoadAttributeOpcode(AttributeOpcode): pass
class StoreAttributeOpcode(AttributeOpcode): pass
class BuildListOpcode(HaveArgsOpcode): pass
class CompareOp(HaveArgsOpcode): pass
class JumpForwardOpcode(RelativeOpcode): pass
class UnpackSequenceOpcode(HaveArgsOpcode): pass
class BuildTupleOpcode(HaveArgsOpcode): pass
class RaiseVarargsOpcode(HaveArgsOpcode): pass

class StoreFastOpcode(FastOpcode): 
    def default(Func, var):
        op = StoreFastOpcode(Func,int_from_op_name('STORE_FAST'),var)
        return op
    default = staticmethod(default)

class StoreDerefOpcode(DerefOpcode):
    def default(Func, var):
        op = StoreDerefOpcode(Func,int_from_op_name('STORE_DEREF'),var)
        return op
    default = staticmethod(default)    

class InplaceAddOpcode(Opcode): 
    def default(Func):
        op = InplaceAddOpcode(Func,int_from_op_name('INPLACE_ADD'),None)
        return op
    default = staticmethod(default)    


def Op_from_int_stream(Func, int_stream):
    """
    An opcode factory. Reads bytes from a queue of bytes and returns an object that
    represents an Opcode that is derived from Opcode
    """
    op = int_stream.pop(0)
    if (op > opcode.HAVE_ARGUMENT):
        args = int_stream.pop(0)+int_stream.pop(0)*256
        if op == int_from_op_name('STORE_FAST'): return StoreFastOpcode(Func,op,args)
        if op == int_from_op_name('LOAD_FAST'): return LoadFastOpcode(Func,op,args)
        if op == int_from_op_name('LOAD_CONST'): return LoadConstOpcode(Func,op,args)
        if op == int_from_op_name('SETUP_LOOP'): return SetupLoopOpcode(Func,op,args)
        if op == int_from_op_name('SETUP_EXCEPT'): return SetupExceptOpcode(Func,op,args)
        if op == int_from_op_name('CALL_FUNCTION'): return CallFunctionOpcode(Func,op,args)
        if op == int_from_op_name('FOR_ITER'): return ForIterOpcode(Func,op,args)
        if op == int_from_op_name('JUMP_ABSOLUTE'): return JumpAbsoluteOpcode(Func,op,args)
        if op == int_from_op_name('LOAD_GLOBAL'): return LoadGlobalOpcode(Func,op,args)
        if op == int_from_op_name('STORE_GLOBAL'): return StoreGlobalOpcode(Func,op,args)
        if op == int_from_op_name('LOAD_ATTR'): return LoadAttributeOpcode(Func,op,args)
        if op == int_from_op_name('STORE_ATTR'): return StoreAttributeOpcode(Func,op,args)
        if op == int_from_op_name('BUILD_LIST'): return BuildListOpcode(Func,op,args)
        if op == int_from_op_name('JUMP_IF_FALSE'): return JumpIfFalseOpcode(Func,op,args)
        if op == int_from_op_name('JUMP_IF_TRUE'): return JumpIfTrueOpcode(Func,op,args)
        if op == int_from_op_name('COMPARE_OP'): return CompareOp(Func,op,args)
        if op == int_from_op_name('JUMP_FORWARD'): return JumpForwardOpcode(Func,op,args)        
        if op == int_from_op_name('UNPACK_SEQUENCE'): return UnpackSequenceOpcode(Func,op,args)        
        if op == int_from_op_name('BUILD_TUPLE'): return BuildTupleOpcode(Func,op,args)        
        if op == int_from_op_name('RAISE_VARARGS'): return RaiseVarargsOpcode(Func,op,args)        
        if op == int_from_op_name('MAKE_FUNCTION'): return HaveArgsOpcode(Func,op,args)        
        raise Exception("Unknown opcode " + op_name_from_int(op)) # not all opcodes are implemented
    return Opcode(Func,op,None)


class Oplist:
    """
    This implements a list of Opcodes. A mode complex operations that are done on a 
    list of    opcodes are implemented in this class.
    """

    def __init__(self,Func = None):
        """
        C'tor 
        Func - a Function object or None for empty list of opcodes.
        """
        # an empty list op opcodes
        if Func == None:
            self.m_ops = []    
            return 

        self.m_ops = []
        # turns the python bytecode string into a stram of bytes
        int_array = map(ord,Func.func.func_code.co_code)

        # read opcodes from the byte stream
        while len(int_array)>0:
            op = Op_from_int_stream(Func, int_array)
            self.m_ops.append(op)    

        self.adjust_addresses()

        # tell each opcode to setup it's argument
        # for example LOAD_CONST (2) turns to LOAD_CONST "hello"
        i = 0 
        while (i< len(self.m_ops)):
            # may add TAG opcodes to list
            self.m_ops[i].process_args(self)
            i += 1

    # should be add opcode after address!
    def add_tag_after_address(self,address,tag):
        """
        Insert a given tag after a given address
        """
        i = 0 
        while (i< len(self.m_ops)):
            if self.m_ops[i].address()==address:
                self.m_ops.insert(i,tag)
                break
            i += 1
        self.adjust_addresses()

    def adjust_addresses(self, start = 0):
        """
        Fix the address field in each of the opcodes from a starting offset
        """
        if (start == 0):
            addr = 0
        else:
            # use previous opcode to for address calculation
            prev = self.m_ops[start-1]
            addr = prev.address() + prev.size()

        fast_m_ops = self.m_ops
        for i in xrange(start,len(self.m_ops)):
            fast_m_ops[i].m_address = addr
            addr += fast_m_ops[i].size()

    def  __getitem__(self,index):
        return self.m_ops[index]

    def  __setitem__(self,index,item):
        self.m_ops[index] = item
    
    def __len__(self): return len(self.m_ops)

    def insert_opcode(self,index,op, adjust = True):
        """
        Inserts a single opcode to the list
        If adjust is true, then it fixes the addresses in the Oplist
        """
        self.m_ops.insert(index,op)
        if adjust == True:
            self.adjust_addresses()

    def append_opcode(self,opcode, adjust = True):
        """
        Append an opcode to the end of the opcode list
        """
        self.insert_opcode(len(self.m_ops),opcode, adjust)
 
    def search_opcode_list(self, name_list, start = 0):
        """
        Searches for a list of opcode names inside the Oplist. 
        Returns index, OpcodeNotFoundException if not found
        """
        for i in xrange(start,len(self.m_ops)-len(name_list)):
            match = True
            for j in xrange(len(name_list)):
                if self.m_ops[i+j].name() != name_list[j]:
                    match = False
                    break
            if match == True: return i
        raise OpcodeNotFoundException("no match")    

    def clone(self):
            return self.copy_slice(0,len(self))

    def copy_slice(self, start, length):
        """
        Copy a subset of the oplist to a new Oplist object
        Does resolve pointers to Tags within this section of bytes
        """
        cut = self.m_ops[start:start+length]

        new_list = Oplist()
        for i in xrange(length):
            new_list.insert_opcode(len(new_list),cut[i].clone())
    
        # copy the references of the cloned list
        # say op points to the old copy of an op, we direct it to the new copy
        for op in new_list.m_ops:
            if (op.m_arg!=None) and (op.m_arg in cut):
                    #print "adjusting opcode ", op
                    # todo: This part is slow, make this faster
                    op.m_arg = new_list[cut.index(op.m_arg)]

        new_list.adjust_addresses(0)
        return new_list

    def insert_oplist(self,index,oplist):
        """
        Insert an Oplist into a specific location
        """
        # copy the list to be inserted
        new_list = oplist.copy_slice(0,len(oplist))
    
        # insert one list into the other
        count = 0
        for op in new_list:
            self.m_ops.insert(index+count,op)
            count += 1

        self.adjust_addresses(index)

    def append_oplist(self,oplist):
        """
        Append a list of opcodes to the end of the list
        """
        self.insert_oplist(len(self.m_ops),oplist)
        
    def del_opcode(self,index, num = 1):
        """
        Delete opcodes at a given location
        """
        for i in xrange(num):
            #print "deleting ",  self.m_ops[index]
            del self.m_ops[index]
        self.adjust_addresses(index)

    def assemble(self):    
        """
        Return this as a list of bytes
        """
        out = []
        for i in self.m_ops:
            i.write(out)
        return out

    def disassemble(self):
        """
        Returns a string to be printed on screen
        """
        sb = ""
        for o in self.m_ops:
            sb += o.to_string() + "\n"
        return sb
