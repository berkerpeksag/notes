#!/usr/bin/python2.4

# Unrolling of xrange and range functions

import logging
from Opcode import  *
from Function import  *

range_funcs = ['xrange','range']

def add_offset_to_induction_variable(Func, oplist,induction_index,const):
    i = 0
    while (i<len(oplist)):
        if oplist[i].name()=='LOAD_FAST':
            if oplist[i].m_arg == induction_index:
                oplist.insert_opcode(i+1, LoadConstOpcode.from_const(Func,1))
                oplist.insert_opcode(i+2, Opcode.default(Func,'INPLACE_ADD'))
        i+=1



# find the first "xrange(10)" function form in the bytecode
def find_first_xrange1(func, start = 0):
    ops = func.get_oplist()
    t = start
    while(1):
        t = ops.search_opcode_list(['SETUP_LOOP','LOAD_GLOBAL','LOAD_CONST','CALL_FUNCTION'], t)
        if (ops[t+1].m_arg in range_funcs):
            if ops[t+3].m_arg == 1:
                return t
        t+=1
    raise OpcodeNotFoundException("xrange not found")


# open an xrange with one param to a 3-paramed xrange
def open_first_xrange_args(Func):
    ops = Func.get_oplist()

    try:
        loop_target = find_first_xrange1(Func,0)
    except OpcodeNotFoundException:
        return Func
    logging.debug("expanding xrange loop to 3 parameters")

    # fix the param that tells xrange that it has 3 arguments
    ops[loop_target+3].m_arg += 2
    ops.insert_opcode(loop_target+2, LoadConstOpcode.from_const(Func,0))
    ops.insert_opcode(loop_target+4, LoadConstOpcode.from_const(Func,1))

    Func.set_oplist(ops)
    return Func 

def open_xrange_args(func, times = 10):    
    for i in xrange(times):
        func = open_first_xrange_args(func)
    return func

# locate an xrange loop with 3 params
def find_first_unrolled_xrange3(func, start = 0):
    ops = func.get_oplist()
    print ops.disassemble()
    t = ops.search_opcode_list(['SETUP_LOOP','LOAD_GLOBAL','LOAD_CONST','LOAD_CONST','LOAD_CONST','CALL_FUNCTION','GET_ITER','TAG','FOR_ITER'], start)
    if ops[t+1].m_arg in range_funcs:
        if ops[t+5].m_arg == 3: #param number
            if ops[t+4].m_arg == 1: # step param
                return t
    raise OpcodeNotFoundException("loop not found")

def unroll_xrange(func, unroll_num= 2):
    loop_target = 0
    try:
        # places where xrange is used
        while (1):
            loop_target = find_first_unrolled_xrange3(func,loop_target)
            unroll_xrange_from_given_loop(func, unroll_num, loop_target)
            loop_target += 1
    except OpcodeNotFoundException:
        return func

def unroll_xrange_from_given_loop(func, unroll_num, loop_target):
    ops = func.get_oplist()
    logging.debug("unrolling xrange loop " + str(unroll_num) + "times")

    # xrange(?,X,?)
    iterations = ops[loop_target+3].m_arg
    for_iter = ops[loop_target+8]
    first_store = ops[loop_target+9]

    # where the actual code starts
    loop_base_index = loop_target+10

    # we can't unroll more than the number of constant iterations
    if (iterations<unroll_num):
        unroll_num = iterations
        #cha ching! we can later get rid of the enitre loop 

    #setup loop jump to num, xrange(?,?,num) 
    ops[loop_target+4].m_arg = ops[loop_target+4].m_arg * unroll_num

    if (iterations % unroll_num <> 0):
        slack = iterations%unroll_num
        # set the iteration numbers to one iteration less, to allow tail
        ops[loop_target+3].m_arg = iterations - unroll_num
    else :
        slack = 0
    
    #count loop body size
    count = 0
    while (ops[count + loop_base_index] != for_iter.m_arg):
        #print ops[count + loop_base_index] ,  "--", for_iter.m_arg
        count += 1
    
    # get the loop body from the code
    body = ops.copy_slice(loop_target+10,count-1)
        
    #print "body\n", body.disassemble()    

    # find induction index from STORE opcode (typically "i")
    induction_index = first_store.m_arg

    #print "dumping old body"
    # remove old code
    ops.del_opcode(loop_base_index,len(body))

    # if we can remove the loop, we shall do so
    if (unroll_num == iterations):
        #print "unrolling code completly"
        index_variable_start_value = ops[loop_target+2].m_arg
        ops.del_opcode(loop_target,14)
        ops.insert_opcode(loop_target,StoreFastOpcode.from_store_fast(func,induction_index))
        ops.insert_opcode(loop_target,LoadConstOpcode.from_const(func,index_variable_start_value))
        loop_base_index = loop_target+2

    # construct the new body
    unrolled_body = Oplist()

    #print "constructing body"
    # for each time we unroll
    for i in xrange(unroll_num):
        unrolled_body.insert_oplist(len(unrolled_body),body)
        # turn induction variable in this iteration to the correct value
        add_offset_to_induction_variable(func, body,induction_index,1)

    #print "inserting body"
    # insert the new body
    ops.insert_oplist(loop_base_index,unrolled_body)

    # construct the tail of the loop
    tail = Oplist()

    #print "constructing tail"
    # for each iteration in the tail (less than a single roll)
    for i in xrange(slack):
        tail.insert_oplist(len(tail),body)
        # turn induction variable in this iteration to the correct value
        add_offset_to_induction_variable(func, body,induction_index,1)

    # insert the tail after the loop is finished
    end_of_loop = loop_base_index + len(unrolled_body) + 2 
    ops.insert_oplist(end_of_loop,tail)

    func.set_oplist(ops)
    return func


