#!/usr/bin/python2.4

# some code to test

import time

def small_bench(func,name):
	"""
	a simple benchmarking method
	"""
	print "benchmarking ",name
	t1 = time.time()
	val = func()
	t2 = time.time()
	print "time:",t2-t1,"Sec"
	return val,t2-t1


##################  test functions  ##################

v = 80023
def func_0():
	"""BasicLoop0"""
	s = 0
	for i in xrange(v):
		s += 6
	return s

def func_1():
	"""BasicLoop1"""
	sum = 0
	for i in xrange(129123 + 67):
		sum += i

def func_2():
	"""BasicLoop1"""
	sum = 0
	for i in xrange(1291023):
		sum += i


def func_3():
	"""BasicLoop2"""
	sum = 0
	for i in xrange(80000):
		sum += i 

def func_4():
	"""LoopArith0"""
	sum = 0
	for i in xrange(921236):
		sum += 4*(i + 9)*20
	return sum


f5_const = 223412
def func_5():
	"""LoopArith1"""
	sum = 0
	for i in xrange(f5_const):
		sum += (7*i + i*8)*5 + 6*(i*5+9)+ 85 + 8 + 9
	return sum

f6_const = 274239
def func_6():
	"""LoopArithList0"""
	sum = 0
	for i in xrange(f6_const):
		for num in [1,2,3,4,5]:
			sum += num * 90
	return sum

def func_7():
	"""LoopArithBranch0"""
	for i in xrange(2823419):
		s = 0
		while (s<>0):
			sum = 1
		r = 4
	return 3


def func_8():
	"""LoopArithForEach0"""
	sum = 0
	for i in xrange(834289):
		for num in [1,2,3,4,5]:
			sum += num * 80 + 9
	return sum

f9_const = 282515
ar = [12]
def func_9():
	"""LoopArithForEach1"""
	sum = 0
	for i in xrange(f9_const):
		sum += i + ar[0]
	return sum 

func10_const = 883156
def func_10():
	"""LoopCall0"""
	sum = 0
	for i in xrange(func10_const):
		sum += int(str(i+3))
	return sum 

a = 5
b = 9
def func_11():
	"""LoopExp0"""
	ZERO = 0
	global a
	sum = ZERO
	for i in xrange(2823452):
		a = ZERO
		sum += a + b
	return sum 

def func_12():
	"""LoopExp1"""
	sum = 0
	c = 2
	for i in xrange(2732235):
		sum += ((7*i) + (i*5))*9
	return sum


def func_13():
	"""LoopArithInduction0"""
	sum = 0
	c = 2
	for i in xrange(2830342):
		sum += ((7*i + i*8)*5+ 7*7+ c + 6*(i*5+9))*9+ 85 + 8 + 9
	return sum

def func_14():
	"""LoopList0"""
	sb = []
	for i in xrange(170236):
		sb.append( str(i*9 + 8*7 + 7*i))
	return sb

def func_15():
	"""LoopRoll0"""
	g = (2911222)
	for i in xrange(g):
		t = i
	return t

def func_16():
	"""ListRoll0"""
	j=0
	while(j<100000):
		j+=1
		for i in [1,2,3,4,5,6]:
			x = i
	return x

def func_17():
	"""LoopRollListRoll0"""
	sum = 0
	for i in xrange(25832):
		for j in [1,8*4,3,2]:
			sum += j*2+45
	return sum

L = 200000
def func_18():
	"""IronPythonDemo0"""
	gd = globals()
	for i in range(L):
		gd['gx'] = i; gd['gx'] = i; gd['gx'] = i; gd['gx'] = i; gd['gx'] = i;
		gd['gx'] = i; gd['gx'] = i; gd['gx'] = i; gd['gx'] = i; gd['gx'] = i;
		gd['gx'] = i; gd['gx'] = i; gd['gx'] = i; gd['gx'] = i; gd['gx'] = i;
		gd['gx'] = i; gd['gx'] = i; gd['gx'] = i; gd['gx'] = i; gd['gx'] = i;
	return gd['gx']

def minor_1(x):
	return x + 3

def major_1():
	sum = 0
	for i in xrange(2940345):
		sum += minor_1(9)
	return sum
