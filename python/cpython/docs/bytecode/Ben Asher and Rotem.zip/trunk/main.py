#!/usr/bin/python2.4

# this file is a demo file for the passes
import time
from optimizer import *
from tests import *
import new
import dis

def func32():
    print "Hello"
    Z = 7
    print "stop"
    for i in xrange(90):
        print 5
        #if (i>5): print i
        #print "hello"
    print "Done"


func = Function.Function(func32)
f = ParallelXrange.convert_variables_to_closure(func)
f = f.get_func()
#F = F.get_func()
dis.dis(f)
f()

#dis.dis(func32)
#F(1,2,3)

