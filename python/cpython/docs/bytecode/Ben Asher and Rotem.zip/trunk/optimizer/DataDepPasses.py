#!/usr/bin/python2.4

# In this file I implement all of the optimization passes over the 
# Data Dependency Tree. See DataDepTree First

# all of the passes in the tree are implemented using the visitor pattern
import logging

from Opcode import *

class Visitor:
    """
    visitor base class. All passes should inharit from this class
    """
    def visit(self): return False

class PrintVisitor(Visitor):
    """
        a sample visitor to show how to write a simple pass
    """
    def visit(self,data_dependency_node):
        print str((data_dependency_node.m_op))
        return False



def find_all_constant_childs_for_subtree(dn_in,type_name, type_name_searched):
    """
    A helper function for DeepAddJoinConstantVisitor
    returns a list of DDNode that are below our node. returns nodes that are
    of a searched type and below a list nodes of a given type;
    for example, a constant that is directly below "ADD"
    """
    matches = []
    queue = [dn_in]
    while (len(queue)>0):
        dn = queue.pop(0)
        # if this is our target
        if dn.m_op.name().endswith(type_name_searched) and not dn in matches: matches.append(dn)
        if dn.m_op.name().endswith(type_name): queue += dn.m_deps
    return matches

class DeepAddJoinConstantVisitor(Visitor):
    """
    Join all constants in an Add or Mul tree to a single value
    """
    def __init__(self): self.m_ops = []

    def visit(self,data_dependency_node):
        name = data_dependency_node.m_op.name()
        if  name.endswith("_ADD"):
                matches = find_all_constant_childs_for_subtree(data_dependency_node,"_ADD","LOAD_CONST")
                if len(matches)<2: return False # one const, nothing to do
                sum = 0
                if type("") == type(matches[0].m_op.m_arg): sum = ""
                for dn in matches:
                    dn.m_op = dn.m_op.clone() # just in case we have two opcodes mapped to the same object
                    sum += dn.m_op.m_arg
                    dn.m_op.m_arg = 0
                matches[0].m_op.m_arg = sum
                logging.debug("DeepAddJoinConstantVisitor" + str(sum))
                return True
        if  name.endswith("_MULTIPLY"):
                matches = find_all_constant_childs_for_subtree(data_dependency_node,"_MULTIPLY","LOAD_CONST")
                if len(matches)<2: return False # one const, nothing to do
                sum = 1
                for dn in matches:
                    dn.m_op = dn.m_op.clone()
                    sum *= dn.m_op.m_arg
                    dn.m_op.m_arg = 1
                matches[0].m_op.m_arg = sum
                logging.debug("DeepAddJoinConstantVisitor" + str(sum))
                return True
        return False

class JoinMullSepAddMultVisitor(Visitor):

    def __init__(self): self.m_ops = []
    def visit(self,data_dependency_node):
        """
              +
            /   \
               +     +
              / \   / \
             *   b *   c
    to
              +
            /   \
               +     +
              / \   / \
             *   * b   c


        """
        if data_dependency_node.m_op.name().endswith("_ADD"):
            left  = data_dependency_node.m_deps[0]
            right = data_dependency_node.m_deps[1]
            if left.m_op.name().endswith("_ADD") and right.m_op.name().endswith("_ADD"):
                left_l  = left.m_deps[0]
                left_r = left.m_deps[1]
                right_l  = right.m_deps[0]
                right_r = right.m_deps[1]

                found = False
                # arrange branches to the right place
                if left_l.m_op.equals(right_l.m_op):
                    found = True
                if left_l.m_op.equals(right_r.m_op):
                    found = True
                    right.m_deps.reverse()
                if left_r.m_op.equals(right_l.m_op):
                    found = True
                    left.m_deps.reverse()
                if left_r.m_op.equals(right_r.m_op):
                    found = True
                    left.m_deps.reverse()
                    right.m_deps.reverse()

                if found and left_l.m_op.name().endswith('_MULTIPLY'):
                    left.m_deps[1],right.m_deps[0] = right.m_deps[0],left.m_deps[1]
                    logging.debug("JoinMullSepAddMultVisitor")
                    return True

        return False
class JoinAddSepMullMultVisitor(Visitor):

    def __init__(self): self.m_ops = []
    def visit(self,data_dependency_node):
        """
              +
            /   \
               *     *
              / \   / \
             a   b a   c
    to
              *
            /   \
               +     a
              / \
             c   b


        """
        if data_dependency_node.m_op.name().endswith("_ADD"):
            left  = data_dependency_node.m_deps[0]
            right = data_dependency_node.m_deps[1]
            if left.m_op.name().endswith("_MULTIPLY") and right.m_op.name().endswith("_MULTIPLY"):
                left_l  = left.m_deps[0]
                left_r = left.m_deps[1]
                right_l  = right.m_deps[0]
                right_r = right.m_deps[1]

                found = False
                # arrange branches to the right place
                if left_l.m_op.equals(right_l.m_op):
                    found = True
                if left_l.m_op.equals(right_r.m_op):
                    found = True
                    right.m_deps.reverse()
                if left_r.m_op.equals(right_l.m_op):
                    found = True
                    left.m_deps.reverse()
                if left_r.m_op.equals(right_r.m_op):
                    found = True
                    left.m_deps.reverse()
                    right.m_deps.reverse()

                if len(left_l.m_deps)!=0: return False  # unable to deal with a with dependancies
                if len(left_r.m_deps)!=0: return False  # unable to deal with a with dependancies
                if len(right_l.m_deps)!=0: return False # unable to deal with a with dependancies
                if len(right_r.m_deps)!=0: return False # unable to deal with a with dependancies

                if found:
                    # swap opcodes
                    a = left.m_deps[0]
                    c = right.m_deps[1]
                    data_dependency_node.m_deps[1] = a
                    left.m_deps[0] = c

                    # swap operators
                    data_dependency_node.m_op, left.m_op = left.m_op,data_dependency_node.m_op
                    logging.debug("JoinAddSepMullMultVisitor")
                    return True
        return False

class JoinDeepMultVisitor(Visitor):

    def __init__(self): self.m_ops = []
    def visit(self,data_dependency_node):
        """
              +
            /   \
               +     *
              / \
             *   ?
        to
              +
            /   \
               +     ?
              / \
             *   *
        """
        if data_dependency_node.m_op.name().endswith("_ADD"):
            left  = data_dependency_node.m_deps[0]
            right = data_dependency_node.m_deps[1]
            for i in range(2):
                data_dependency_node.m_deps.reverse()
                if left.m_op.name().endswith("_ADD") and right.m_op.name().endswith("_MULTIPLY"):
                    for i in range(2):
                        left.m_deps.reverse()
                        left_l = left.m_deps[0]
                        left_r = left.m_deps[1]
                        if left_l.m_op.name().endswith("_MULTIPLY"):
                            left.m_deps[1],data_dependency_node.m_deps[0] = data_dependency_node.m_deps[0],left.m_deps[1]
                            logging.debug("JoinDeepMultVisitor")
                            return True
        return False

class LevelAddExpVisitor(Visitor):

    def __init__(self): self.m_ops = []
    def visit(self,data_dependency_node):
        """
              +
            /   \
               +     V
              / \
             +   V
        to
              +
            /   \
               +     +
              / \
             V   V

        """
        if data_dependency_node.m_op.name().endswith("_ADD"):
            left  = data_dependency_node.m_deps[0]
            right = data_dependency_node.m_deps[1]
            if left.m_op.name().endswith("_ADD") and not right.m_op.name().endswith("_ADD"):
                left_l  = left.m_deps[0]
                right_l = left.m_deps[1]
                if left_l.m_op.name().endswith("_ADD") and not right_l.m_op.name().endswith("_ADD"):
                    left.m_deps[0],data_dependency_node.m_deps[1] = data_dependency_node.m_deps[1],left.m_deps[0]
                    logging.debug("LevelAddExpVisitor")
                    return True
                if right_l.m_op.name().endswith("_ADD") and not left_l.m_op.name().endswith("_ADD"):
                    left.m_deps[1],data_dependency_node.m_deps[1] = data_dependency_node.m_deps[1],left.m_deps[1]
                    logging.debug("LevelAddExpVisitor")
                    return True
            if right.m_op.name().endswith("_ADD") and not left.m_op.name().endswith("_ADD"):
                left_r  = right.m_deps[0]
                right_r = right.m_deps[1]
                if left_r.m_op.name().endswith("_ADD") and not right_r.m_op.name().endswith("_ADD"):
                    right.m_deps[0],data_dependency_node.m_deps[0] = data_dependency_node.m_deps[0],right.m_deps[0]
                    logging.debug("LevelAddExpVisitor")
                    return True
                if right_r.m_op.name().endswith("_ADD") and not left_r.m_op.name().endswith("_ADD"):
                    right.m_deps[1],data_dependency_node.m_deps[0] = data_dependency_node.m_deps[0],right.m_deps[1]
                    logging.debug("LevelAddExpVisitor")
                    return True
        return False

class ConstMulExtractVisitor(Visitor):

    def __init__(self): self.m_ops = []

    def visit(self,data_dependency_node):
        """
              *
                / \
               C   +
              / \
             C   ?
    TO
              +
                / \
               C   *
              / \
             C   ?

        """
        name = data_dependency_node.m_op.name()
        if  name.endswith("_MULTIPLY"):
            for i in range(2):
                data_dependency_node.m_deps.reverse()
                left  = data_dependency_node.m_deps[0]
                right = data_dependency_node.m_deps[1]
                if left.m_op.name() == 'LOAD_CONST' and right.m_op.name().endswith("_ADD"):
                    left_r  = right.m_deps[0]
                    right_r = right.m_deps[1]
                    if left_r.m_op.name().endswith("LOAD_CONST"):
                        left.m_op.m_arg,left_r.m_op.m_arg =left_r.m_op.m_arg,left.m_op.m_arg
                        left.m_op.m_arg *= left_r.m_op.m_arg
                        data_dependency_node.m_op,right.m_op = right.m_op,data_dependency_node.m_op
                        logging.debug("ConstMulExtractVisitor")
                        return True
                    if right_r.m_op.name().endswith("LOAD_CONST"):
                        left.m_op.m_arg,right_r.m_op.m_arg =right_r.m_op.m_arg,left.m_op.m_arg
                        left.m_op.m_arg *= right_r.m_op.m_arg
                        data_dependency_node.m_op,right.m_op = right.m_op,data_dependency_node.m_op
                        logging.debug("ConstMulExtractVisitor")
                        return True
        return False

class JoinDoubleLoadVisitor(Visitor):

    def __init__(self): self.m_ops = []

    def visit(self,data_dependency_node):
        """
        Turns LOAD+LOAD to LOAD*2
        """
        name = data_dependency_node.m_op.name()
        if  name.endswith("_ADD"):
            left  = data_dependency_node.m_deps[0]
            right = data_dependency_node.m_deps[1]
            if left.m_op.name() == 'LOAD_FAST' and right.m_op.name() == 'LOAD_FAST' and left.m_op.m_arg == right.m_op.m_arg:
                Func = data_dependency_node.m_op.Func
                data_dependency_node.m_op = Opcode.default(Func,'INPLACE_MULTIPLY')
                left.m_op = LoadConstOpcode.from_const(Func,2)
                data_dependency_node.m_op.m_address = 0
                left.m_op.m_address = 0
                logging.debug("JoinDoubleLoadVisitor")
                return True
        return False

class JoinAddZeroVisitor(Visitor):

    def __init__(self): self.m_ops = []

    def visit(self,data_dependency_node):
        """
        turns a*0 to 0 
        turns a*1 to a
        turns a+0 to a
        """
        name = data_dependency_node.m_op.name()
        if  name.endswith("_ADD"):
            left  = data_dependency_node.m_deps[0]
            right = data_dependency_node.m_deps[1]
            if left.m_op.name() == 'LOAD_CONST' and left.m_op.m_arg == 0:
                data_dependency_node.m_op = right.m_op
                data_dependency_node.m_deps = right.m_deps
                logging.debug("JoinAddZeroVisitor")
                return True
            if right.m_op.name() == 'LOAD_CONST' and right.m_op.m_arg == 0:
                data_dependency_node.m_op = left.m_op
                data_dependency_node.m_deps = left.m_deps
                logging.debug("JoinAddZeroVisitor")
                return True
        if  name.endswith("_MULTIPLY"):
            left  = data_dependency_node.m_deps[0]
            right = data_dependency_node.m_deps[1]
            if left.m_op.name() == 'LOAD_CONST' and left.m_op.m_arg == 1:
                data_dependency_node.m_op = right.m_op
                data_dependency_node.m_deps = right.m_deps
                logging.debug("JoinAddZeroVisitor")
                return True
            if right.m_op.name() == 'LOAD_CONST' and right.m_op.m_arg == 1:
                data_dependency_node.m_op = left.m_op
                data_dependency_node.m_deps = left.m_deps
                logging.debug("JoinAddZeroVisitor")
                return True
            # needs more testing below
            if left.m_op.name() == 'LOAD_CONST' and left.m_op.m_arg == 0:
                data_dependency_node.m_op = left.m_op
                data_dependency_node.m_deps = left.m_deps
                logging.debug("JoinAddZeroVisitor")
                return True
            if right.m_op.name() == 'LOAD_CONST' and right.m_op.m_arg == 0:
                data_dependency_node.m_op = right.m_op
                data_dependency_node.m_deps = right.m_deps
                logging.debug("JoinAddZeroVisitor")
                return True
        return False


class ConstComperatorInline(Visitor):
 
    def __init__(self): self.m_ops = []

    def visit(self,data_dependency_node):
        """
        turns 5 > 4 to True
        """
        name = data_dependency_node.m_op.name()
        if  name.endswith("COMPARE_OP"):
            left  = data_dependency_node.m_deps[0]
            right = data_dependency_node.m_deps[1]
            if left.m_op.name() == 'LOAD_CONST' and right.m_op.name() == 'LOAD_CONST':
                val = 0 
                # <
                if data_dependency_node.m_op.m_arg == 0:
                    val = (right.m_op.m_arg < left.m_op.m_arg)
                # >
                if data_dependency_node.m_op.m_arg == 4:  # could be the other way around
                    val = (right.m_op.m_arg > left.m_op.m_arg)
                # == 
                if data_dependency_node.m_op.m_arg == 2:
                    val = (right.m_op.m_arg == left.m_op.m_arg)
                # != 
                if data_dependency_node.m_op.m_arg == 3:
                    val = (right.m_op.m_arg != left.m_op.m_arg)

                # load the value of the comperator
                right.m_op.m_arg = val
                data_dependency_node.m_op = right.m_op
                data_dependency_node.m_deps = right.m_deps
                logging.debug("ConstComperatorInline")
                return True
        return False

class ReplaceOpcodeVisitor(Visitor):

    def __init__(self,src,dst):
        self.m_ops = []
        self.m_src = src
        self.m_dst = dst
        self.count = 0

    def visit(self,data_dependency_node):
        """
         a simple helper visitor that replaces opcodes in a tree
        """
        flag = False
        for i in xrange(len(data_dependency_node.m_deps)):
            if data_dependency_node.m_deps[i] == self.m_src:
                #logging.debug("replacing " + str(data_dependency_node.m_deps[i]) + " with " + str(self.m_dst))
                data_dependency_node.m_deps[i] = self.m_dst.clone()
                self.count += 1
                flag = True
        return flag

class SearchOpcodeVisitor(Visitor):
    """
    a simple search visitor to search for opcodes
    """
    def __init__(self,name,arg = None, no_arg = False):
        self.m_match = []
        self.m_opnum = int_from_op_name(name) 
        self.m_arg = arg
        self.no_arg = no_arg

    def visit(self,data_dependency_node):
        if self.no_arg:
            if data_dependency_node.m_op.m_op == self.m_opnum:
                self.m_match.append(data_dependency_node)
        else:
            if data_dependency_node.m_op.m_op == self.m_opnum and data_dependency_node.m_op.m_arg == self.m_arg:
                self.m_match.append(data_dependency_node)
        return (0 == len(self.m_match))

class SearchIDVisitor(Visitor):
    """
    a simple search that collects the ids of all ops in the system
    this is used to make sure that we don't have duplicates in our tree
    (debug)
    """
    def __init__(self):
        self.m_match = []
 
    def visit(self,data_dependency_node):
        op = data_dependency_node.m_op
        if id(op) in self.m_match: raise ValueError("id match twice" + str(data_dependency_node))
        self.m_match.append(id(op))
        return False





class ConstantSubtract(Visitor):

    def __init__(self): self.m_ops = []

    def visit(self,data_dependency_node):
        """
        turns 5-4 to 1
        """
        name = data_dependency_node.m_op.name()
        if  name.endswith("BINARY_SUBTRACT"):
            left  = data_dependency_node.m_deps[0]
            right = data_dependency_node.m_deps[1]
            if left.m_op.name() == 'LOAD_CONST' and right.m_op.name() == 'LOAD_CONST':
                data_dependency_node.m_op = left.m_op
                data_dependency_node.m_op.m_arg = left.m_op.m_arg - right.m_op.m_arg 
                data_dependency_node.m_deps = []
                logging.debug("ConstantSubtract:" + str(left.m_op.m_arg ) + "-" + str(right.m_op.m_arg))
                return True
        return False
