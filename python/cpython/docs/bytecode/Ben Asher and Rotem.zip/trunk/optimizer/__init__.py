# Pykangaroo, I really need to change this name
"A bytecode level optimizing infrastructure for python"

__author__ = 'Nadav Rotem'
__version__ = '0.0.2'

from Opcode import *
from Function import *
from DataDepTree import *
from DataDepPasses import *
from Passes import *
from Inliner import *
from UnrollXrange import *
from UnrollForeachList import *

from optimizations import *
from CFG import *

import UnrollDynamicXrange
import UnrollListToRandomAccess
