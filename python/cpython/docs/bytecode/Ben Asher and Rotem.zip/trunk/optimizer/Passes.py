#!/usr/bin/python2.4

# simple passes over python code

from Opcode import  *
from Function import  *


global_cache_prefix = "$$$_global_cache_"
def cache_global_calls(func):
	"""
	Cache each global call so it is called once. 
	Note: This must be called after unroll-xrange since it looks for global 'xrange'
		and not for the local one
	"""
	ops = func.get_oplist()
	#print "caching global calls [",
	#print __builtins__.keys()
	# make global list
	global_vars = []
	keys = __builtins__.keys()
	i = 0
	# cache all __builtins__
	while i< len(ops.m_ops):
		if ops.m_ops[i].name() == 'LOAD_GLOBAL':
			if ops.m_ops[i].m_arg in keys:
					if not ops.m_ops[i].m_arg in global_vars: global_vars.append(ops.m_ops[i].m_arg)
					#print ops.m_ops[i].m_arg, 
					ops.m_ops[i] = LoadFastOpcode.from_load_fast(func,global_cache_prefix + ops.m_ops[i].m_arg)
		i+=1

	store_global_vars = []
	i = 0
	# cache all constants
	while i< len(ops.m_ops):
		if ops.m_ops[i].name() == 'STORE_GLOBAL':
			store_global_vars.append(ops.m_ops[i].m_arg)
		i+=1	
	i = 0 
	# for all variables that are read only
	while i< len(ops.m_ops):
		if ops.m_ops[i].name() == 'LOAD_GLOBAL':
			if not ops.m_ops[i].m_arg in store_global_vars:
					if not ops.m_ops[i].m_arg in global_vars: global_vars.append(ops.m_ops[i].m_arg)
					#print ops.m_ops[i].m_arg,
					ops.m_ops[i] = LoadFastOpcode.from_load_fast(func,global_cache_prefix + ops.m_ops[i].m_arg)
		i+=1	

	opl = Oplist()
	for glob in global_vars:
		opl.append_opcode(GlobalOpcode.from_load_global(func,glob))
		opl.append_opcode(StoreFastOpcode.from_store_fast(func,global_cache_prefix + glob))

	# insert the loads of the global calls to the beginning of the code
	ops.insert_oplist(0,opl)	
	#print "] done"
	func.set_oplist(ops)
	return func




local_read_prefix = "$$$_local_read"
def cache_read_only_arrays(func):
	"""
	0 LOAD_FAST                2 (F)
	3 LOAD_CONST
	6 BINARY_SUBSCR
	"""
	ops = func.get_oplist()
	
	opl = Oplist()

	write = []
	i = 0
	# search for write calls and remove them from list
	while i< len(ops.m_ops):
		if ops.m_ops[i].name() == 'LOAD_FAST':
			if ops.m_ops[i+1].name() == 'LOAD_CONST':
				if ops.m_ops[i+2].name() == 'STORE_SUBSCR':
					write.append(ops.m_ops[i].m_arg)
		i+=1

	
	read = []
	i = 0
	# search for read calls
	while i< len(ops.m_ops):
		if ops.m_ops[i].name() == 'LOAD_FAST':
			if ops.m_ops[i+1].name() == 'LOAD_CONST':
				if ops.m_ops[i+2].name() == 'BINARY_SUBSCR':
					if not ops.m_ops[i].m_arg in write:
						read.append( (ops.m_ops[i].m_arg,ops.m_ops[i+1].m_arg) )
		i+=1
		


	mangled_names = {}
	for var,ind in read:
		mangled_name = local_read_prefix + var +'@'+ str(ind) # add array name to variables that are being read
		mangled_names[(var,ind)] = mangled_name
		#print 'adding',var,'as',mangled_name
		opl.append_opcode(FastOpcode.from_load_fast(func,var))
		opl.append_opcode(LoadConstOpcode.from_const(func,ind))
		opl.append_opcode(Opcode(func,int_from_op_name('BINARY_SUBSCR')))
		opl.append_opcode(FastOpcode.from_store_fast(func,mangled_name))


	i = 0
	while i< len(ops.m_ops):
		if ops.m_ops[i].name() == 'LOAD_FAST':
			if ops.m_ops[i+1].name() == 'LOAD_CONST':
				if ops.m_ops[i+2].name() == 'BINARY_SUBSCR':
					# fill in all of the replaced vars
					 ops.m_ops[i] = FastOpcode.from_load_fast(func,mangled_names[(ops.m_ops[i].m_arg,ops.m_ops[i+1].m_arg)])
					 ops.m_ops[i+1] = TagOpcode(func,0)
					 ops.m_ops[i+2] = TagOpcode(func,0)
					 #ops.del_opcode(i+1)
					 #ops.del_opcode(i+1)
		i+=1


	# insert the loads of the global calls to the beginning of the code
	ops.insert_oplist(0,opl)	
	func.set_oplist(ots)
	return func
