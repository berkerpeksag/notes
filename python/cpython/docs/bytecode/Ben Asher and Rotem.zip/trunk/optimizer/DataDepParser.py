#!/usr/bin/python2.4

from Opcode import  *
from Function import  *
import logging

temporary_tree_storage = []

class ParseErrorException(Exception): pass

def is_op_head_of_tree(op):
        if op.name() == 'STORE_FAST': return True
        if op.name() == 'POP_TOP': return True
        return False

def get_param_number_from_opcode(op):
        if op.name() == 'LOAD_CONST': return 0
        if op.name() == 'LOAD_FAST': return 0
        if op.name() == 'RETURN_VALUE': return 1
        if op.name() == 'LOAD_ATTR': return 1
        if op.name() == 'UNARY_INVERT': return 1
        if op.name() == 'BINARY_ADD': return 2
        if op.name() == 'BINARY_AND': return 2
        if op.name() == 'BINARY_OR': return 2
        if op.name() == 'BINARY_XOR': return 2
        if op.name() == 'BINARY_MULTIPLY': return 2
        if op.name() == 'INPLACE_ADD': return 2
        if op.name() == 'INPLACE_MULTIPLY': return 2
        if op.name() == 'STORE_FAST': return 1
        if op.name() == 'STORE_GLOBAL': return 2
        if op.name() == 'GET_ITER': return 1
        if op.name() == 'POP_TOP': return 1
        if op.name() == 'COMPARE_OP': return 2
        if op.name() == 'PRINT_ITEM': return 1
        if op.name().startswith('JUMP_IF'): return 1
        if op.name() == 'STORE_ATTR': return -2
        if op.name() == 'BINARY_SUBSCR': return -2
        if op.name() == 'BINARY_LSHIFT': return -2
        if op.name() == 'BINARY_RSHIFT': return -2
        if op.name() == 'STORE_SUBSCR': return -3
        if op.name() == 'STORE_SLICE+1': return -3
        if op.name() == 'SLICE+1': return -2
        if op.name() == 'STORE_SLICE+2': return -3
        if op.name() == 'SLICE+2': return -2
        if op.name() == 'STORE_SLICE+3': return -4
        if op.name() == 'SLICE+3': return -3
        if op.name() == 'BINARY_SUBTRACT': return -2
        if op.name() == 'BINARY_DIVIDE': return -2
        if op.name() == 'BINARY_MODULO': return -2
        if op.name() == 'BUILD_TUPLE': return op.m_arg
        if op.name() == 'BUILD_LIST': return op.m_arg
        if op.name() == 'CALL_FUNCTION': return -(op.m_arg + 1)
        return 0

def load_me_a_tree(oplist, head_tree = False):
        # store in tree case
        while (is_op_head_of_tree(oplist[-1]) and (not head_tree)):
            # we have a tree inside a tree case
            global temporary_tree_storage
            temporary_tree_storage.append(load_me_a_tree(oplist, True))
            if 0 == len(oplist): return EmptyNode()

        op = oplist.pop()
        params = get_param_number_from_opcode(op)

        deps = []
        for i in xrange(abs(params)):
            tree = load_me_a_tree(oplist)
            deps.append(tree)
        if (params<0): deps.reverse()

        return DataDependencyNode(op,deps)

class EmptyNode:
    def __init__(self): pass

    def to_string(self,tab=0):
        return "[ Empty Node ]\n"

    def __str__(self): return self.to_string()

    def accept(self,visitor): return False

    def write(self, oplist): pass 

    def __len__(self): return 0

class DataDependencyNode:
    """
    A node in a tree of dependancies. Each node wraps an opcode
    """
    def __init__(self,op, deps):
        self.m_op = op
        self.m_deps = deps


    def to_string(self,tab=0):
        sb = ""
        for i in xrange(tab): sb += '\t'
        sb += str(self.m_op) + "\n"

        for dn in self.m_deps: sb += dn.to_string(tab+1)
        return sb

    def __str__(self):
        return self.to_string()

    def accept(self,visitor):
        """
        Visitor's pattern visit method
        """
        active = False
        for dn in self.m_deps:
            active |= dn.accept(visitor)
        active |= visitor.visit(self)
        return active

    def write(self, oplist):
        """
        write this node recursively to an Oplist structure
        """
        for dn in self.m_deps:
            dn.write(oplist)
        oplist.append_opcode(self.m_op)

    def clone(self):
        return self.__class__(self.m_op.clone(), self.m_deps)

    def __len__(self):
        sum = 0
        for dn in self.m_deps: sum += len(dn)
        return sum + 1


class DataDependencyNodeList:
    """
    Represents a list of Dependency trees in memory
    """
    def __init__(self,oplist):
        self.m_trees = []
        while len(oplist)>0:
            global temporary_tree_storage
            temporary_tree_storage = []
            new_tree = load_me_a_tree(oplist.m_ops, True)
            if new_tree != None: self.m_trees.insert(0,new_tree)
            for tree in temporary_tree_storage:
                if tree != None: self.m_trees.insert(0,tree)

    def __str__(self):
        sb = "\n"
        for dn in self.m_trees:
            sb += str(dn)
        return sb

    def to_oplist(self):
        opl = Oplist()
        for dn in self.m_trees:
            dn.write(opl)
        opl.adjust_addresses()
        return opl


