#!/usr/bin/python2.4

# an Inliner for Python functions 

import logging
from Opcode import  *
from Function import  *

import DataDepParser

def prepare_inlined_function_to_oplist(func_orig):
    """
    """
    import random
    random_name = str(random.randrange(0,1000)) 

    func = Function(func_orig)    
    ops = func.get_oplist()

    name = func.func.func_name
    params = list(func.func.func_code.co_varnames[0:func.func.func_code.co_argcount])

    i = 0
    while i< len(ops.m_ops):
        if ops.m_ops[i].name()=='RETURN_VALUE':
            tag = TagOpcode(func,int_from_op_name('NOP'))
            ops.del_opcode(i)
            ops.insert_opcode(i+1,AbsoluteOpcode.from_jump_absolute(func,tag))
            ops.append_opcode(tag)

            #print "added", tag, "and" , ops.m_ops[i]
        if ops.m_ops[i].name() in ['LOAD_FAST','STORE_FAST']:
                ops.m_ops[i].m_arg += '_inline_' + name + '_' + random_name
        i += 1

    # jump must not be to the code after the last opcode
    ops.append_opcode(Opcode(func,int_from_op_name('NOP')))
    ops.adjust_addresses()


    mod_params = []
    for param in params: mod_params.append(param + '_inline_' + name + '_' + random_name)
    # returns a list of params and params names
    return ops, mod_params


def inline_function(func, inlined_func):
    """
    """
    ops = func.get_oplist()

    func_name = inlined_func.func_name

    i = 0
    while i< len(ops.m_ops):
        if ops.m_ops[i].name()=='CALL_FUNCTION':
            ops2 = Oplist()
            ops2.m_ops = ops.m_ops[:i+1]
            call_tree = DataDepParser.load_me_a_tree(ops2.m_ops, True)
            if (0<len(DataDepParser.temporary_tree_storage)): 
                logging.debug("Some crazy nested function call, aborting!")
            #print str(call_tree)

            local_func_name = call_tree.m_deps[0].m_op.m_arg
            args            = call_tree.m_op.m_arg
            call_tree_len = len(call_tree) 
            #print "len = ", call_tree_len
            if local_func_name == func_name: 

                inops, params = prepare_inlined_function_to_oplist(inlined_func)
                # associate the new opcodes with the current funciton
                for op in inops: op.Func = func

                if args != len(params): 
                    #print "params=",params, "args = ",args
                    raise ValueError(str(len(params)) + "<>" + str(args))

                #for z in xrange(call_tree_len): print "deleting opcodes starting", str(ops[i-call_tree_len+z+1])
                ops.del_opcode(i-call_tree_len +1 , call_tree_len) # del 'CALL_FUNCTION' tree
                #for z in xrange(call_tree_len,call_tree_len+4): print "-------- --------t---- - ", str(ops[i-call_tree_len+z+1])
                

                arguments = Oplist()
                #print "params=",params
                z = 1
                for a in xrange(args):
                    call_tree.m_deps[z].write(arguments)
                    arguments.append_opcode(StoreFastOpcode.from_store_fast(func,params[a]))
                    z+=1
                #print str(arguments.disassemble())
                arguments.append_oplist(inops)
                ops.adjust_addresses()
                #print "new param save list \n\n ",arguments.disassemble(),">>>>"
                #arguments.insert_oplist(inops)    
                ops.insert_oplist(i-call_tree_len+1 ,arguments)
                ops.adjust_addresses()
        i += 1
        # if opcode == yield and such :  raise UnInlinable

    # jump must not be to the code after the last opcode
    ops.append_opcode(Opcode(func,int_from_op_name('NOP')))
    ops.adjust_addresses()

    remove_unneeded_jump_and_nop(ops)
    remove_unneeded_jump_and_nop(ops)
    func.set_oplist(ops)
    return func

def remove_unneeded_jump_and_nop(oplist):
    i = 0
    while i<(len(oplist)-1):
        # remove the unneeded jump to the next opcode
        if oplist[i].name() == 'NOP':
            logging.debug("remove_unneeded_jump_and_nop: deleting " + str(oplist[i]))
            oplist.del_opcode(i)

        if oplist[i].name() == "JUMP_ABSOLUTE" and oplist[i].m_arg == oplist[i+1]:
                logging.debug("remove_unneeded_jump_and_nop: deleting " + str(oplist[i+1]))
                oplist.del_opcode(i+1)
                logging.debug("remove_unneeded_jump_and_nop: deleting " + str(oplist[i]))
                oplist.del_opcode(i) 
        i+=1



