#!/usr/bin/python2.4

# Unrolling lists to random access and reduces it to loop unrolling unrolling
#
import logging
from Opcode import  *
from Function import  *
from DataDepTree import *
from DataDepPasses import *

# find the first loop...
def find_first_iterate_list(func, start = 0):
    ops = func.get_oplist()
    t = start
    return ops.search_opcode_list(['SETUP_LOOP','LOAD_FAST','GET_ITER','TAG','FOR_ITER','STORE_FAST'], t)


def unroll_list(func):
    loop_target = 0
    try:
        # places where xrange is used
        while (1):
            loop_target = find_first_iterate_list(func,loop_target)
            unroll_list_from_given_loop(func, loop_target)
            loop_target += 1
    except OpcodeNotFoundException:
        return func

def unroll_list_from_given_loop(func, loop_target):
    ops = func.get_oplist()

    logging.debug("unrolling list at " + str(loop_target))

    """
     18 LOAD_FAST                2 (lst)
     21 LOAD_ATTR                3 (__len__)
     24 CALL_FUNCTION            0
     27 STORE_FAST               3 (lst_len)
    """
    head = Oplist()
    paramName =  ops[loop_target+1].m_arg 
    head.append_opcode(GlobalOpcode.from_load_global(func,'len'))
    head.append_opcode(FastOpcode.from_load_fast(func,paramName))
    #head.append_opcode(AttributeOpcode.from_load_attr(func,'__len__'))    
    head.append_opcode(CallFunctionOpcode.from_call_function(func,1))
    head.append_opcode(FastOpcode.from_store_fast(func,"$list_len$"))
        
    for_iter = ops[loop_target+4]

    # where the actual code starts
    loop_base_index = loop_target+3
    
    #count loop body size
    count = ops.m_ops.index(for_iter.m_arg) - loop_base_index

    inductionVar = ops[loop_target+5].m_arg

    # build 'list[i]'
    """
    52 LOAD_FAST                2 (lst)
    55 LOAD_FAST                0 (i)
    58 BINARY_SUBSCR                                            
    """
    load_array_index_ops = Oplist()
    load_array_index_ops.append_opcode(FastOpcode.from_load_fast(func,paramName))
    load_array_index_ops.append_opcode(FastOpcode.from_load_fast(func,inductionVar))
    load_array_index_ops.append_opcode(Opcode(func,int_from_op_name('BINARY_SUBSCR')))
        
    # get the loop body from the code
    body = ops.copy_slice(loop_target+6,count-4)
    # delete old body
    ops.del_opcode(loop_target+6,count-4)
    
    # replace all 'i' with 'list[i]'
    iop = 0
    while iop < len(body.m_ops):
        if body[iop].m_op == int_from_op_name('LOAD_FAST') and \
            body[iop].m_arg == inductionVar:
                body.del_opcode(iop)
                body.insert_oplist(iop, load_array_index_ops)
                iop += len(load_array_index_ops)
        iop += 1                


    # reinsert modified body
    ops.insert_oplist(loop_target+6,body)

    # change the loop from 'for i in list' to 'for i in xrange(len)'
    """
    33 LOAD_GLOBAL              5 (xrange)
    36 LOAD_FAST                3 (lst_len)
    39 CALL_FUNCTION   
    """                                          
    randlist = Oplist()
    randlist.append_opcode(GlobalOpcode.from_load_global(func,'xrange'))    
    randlist.append_opcode(FastOpcode.from_load_fast(func,'$list_len$'))
    randlist.append_opcode(CallFunctionOpcode.from_call_function(func,1))

    ops.del_opcode(loop_target+1)
    ops.insert_oplist(loop_target+1,randlist)

    # insert the head
    #head.insert_opcode(2,Opcode(func,int_from_op_name('RETURN_VALUE')))
    ops.insert_oplist(loop_target,head)
 
    func.set_oplist(ops)
    return func


