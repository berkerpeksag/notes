# Pykangaroo, I really need to change this name
"A bytecode level optimizing infrastructure for python"

__author__ = 'Nadav Rotem'
__version__ = '0.0.2'

import Benchmark
import TestCase
import Fir
import rsamd5 as rsamd5
import md5 as pymd5
import sha as pysha
import pystone as pystone

