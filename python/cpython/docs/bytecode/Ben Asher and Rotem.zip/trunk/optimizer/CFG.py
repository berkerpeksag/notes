#!/usr/bin/python2.4

import Opcode
from Opcode import Oplist

class BasicBlock(object):
    def __init__(self):
        self.ops = Oplist()
        self.dst = set()
        self.src = set()
        self.busy = False

    def append_opcode(self,item):		self.ops.append_opcode(item, False)
    def append_src(self,item): 		self.src.add(item)
    def append_dst(self,item): 		self.dst.add(item)
    def get_opcodes_range(self):
        if len(self.ops)>0: return (self.ops[0].address(),self.ops[-1].address())
        return (0,0)


    def __iter__(self): return self.ops.m_ops.__iter__()
    def __len__(self): return len(self.ops)

    def get_loaded_locals(self):
        vars = set()
        for op in self.ops:
            if op.name() == 'LOAD_FAST':
                vars.add(op.m_arg)
        return vars

    def get_stored_locals(self):
        vars = {}
        for op in self.ops:
            if op.name() == 'STORE_FAST':
                vars[op.m_arg] =[self,]
        return vars

    def recursive_get_all_saved_variables(self):
        """
        Recuresively get the list of all used variables, starting from this block
        """
        vars = self.get_stored_locals()
        if self.busy: return vars


        self.busy = True
        for src in self.src:
            dic = src.recursive_get_all_saved_variables()
            for item in dic:
                if item in vars:
                    vars[item].append(dic[item]) # add to list
                else:
                    vars[item] = dic[item]

        self.busy = False
        return vars

    def recursive_get_all_used_variables(self):
        """
        Recuresively get the list of all used variables, starting from this block
        """
        vars = self.get_loaded_locals()
        if self.busy: return vars
        self.busy = True
        for src in self.src: vars.update(src.recursive_get_all_used_variables())
        self.busy = False
        return vars


class OpcodeNotInBagException(Exception): pass

class CFG(object):
    def __init__(self, oplist):
        self.bag = [] # a bag of basic blocks
        self.current = BasicBlock() # an empty list of opcodes
        self.bag.append(self.current)

        for op in oplist:
            self._add(op)
        self._create_deps()

    def _get_bag_from_opcode(self,opcode):
        for block in self.bag:
            if opcode in block: return block
        raise OpcodeNotInBagException(str(opcode))

    def _add(self,opcode):
        if self._should_break_before(opcode) and 0<> len(self.current):
            bb = BasicBlock()
            self.current.append_dst(bb)
            bb.append_src(self.current)
            self.current =  bb
            self.bag.append(self.current)
        self.current.append_opcode(opcode)
        if self._should_break_after(opcode):
            bb = BasicBlock()
            if opcode.name().startswith('JUMP_IF'):
                self.current.append_dst(bb)
                bb.append_src(self.current)
            self.current = bb
            self.bag.append(self.current)

    def _should_break_before(self,opcode):
        if opcode.name() == 'TAG': return True
        return False

    def _should_break_after(self,opcode):
        if opcode.name().startswith('JUMP_'): return True
        return False


    def __str__(self):
        sb = ""
        for block in self.bag:
            sb += "\n\nbag " + str(block) + " \n"
            sb +=  "\tsrc: " + str(block.src) + "\n"
            sb +=  "\tdst: " + str(block.dst) + "\n"
            for op in block: sb += "\t" + str(op) + "\n" 
            sb += "\t loaded locals:" + str(block.get_loaded_locals())
            sb += "\n\t stored locals:" + str(block.get_stored_locals())
            sb += "\n\t recursice use:" + str(block.recursive_get_all_used_variables())
            sb += "\n\t recursice use:" + str(block.recursive_get_all_saved_variables())

            local = block.get_loaded_locals()
            stores = block.recursive_get_all_saved_variables()
            for loc in local:
                if (0 <> len(stores[loc])): print "Inline constant here"

            vv = block.recursive_get_all_saved_variables()
            for var in vv.keys():
                sb += "key:" + str(var) + "_" + str(len(var)) + "\n"
        return sb

    def _create_deps(self):
        """
        Generate all of the dependencies between the basic blocks. 
        """
        for block in self.bag:
            for op in block:
                # is a jump to ? 
                if op.name().startswith('JUMP_') or op.name().startswith('FOR_ITER'):
                    target_bag = self._get_bag_from_opcode(op.m_arg)
                    target_bag.append_src(block)
                    block.append_dst(target_bag)

    def get_constant_list_of_opcodes(self):
        """
        Get a list of tuples of a src and dst opcodes that are constant. 
        """
        for block in self.bag:
            pass

    def toOplist(self):
        out = Oplist()
        for i in xrange(len(self.bag)):
            out.append_oplist(self.bag[i].ops)
        out.adjust_addresses()
        return out
