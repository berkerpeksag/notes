#!/usr/bin/python2.4

# python bytecode handling Functions

import new
from Opcode import Oplist

class Function:
    """
    A class that represents and wraps a python function
    """
    
    def __init__(self, afunc):
        self.func = afunc
        self.m_op_list = Oplist(self)
    
    def get_constant(self, index):
        """
        Returns a constant used by the function
        """
        return self.func.func_code.co_consts[index]

    def make_new_function(self, oplist, params=tuple()):
        co = self.func.func_code
        codeobj = type(co)(len(params), co.co_nlocals, co.co_stacksize + 4, co.co_flags, co.co_code, co.co_consts, co.co_names, params, co.co_filename, co.co_name, co.co_firstlineno, co.co_lnotab, co.co_freevars, co.co_cellvars)
        func = type(self.func)(codeobj, self.func.func_globals, 'unnamed', self.func.func_defaults ,self.func.func_closure)
        F = Function(func)
        for op in oplist: op.Func = F
        F.set_oplist(oplist)
        return F

    def make_closure(self):
        """
        """
        co = self.func.func_code
        # 3 is the flag number for closure
        codeobj = new.code(co.co_argcount, co.co_nlocals, co.co_stacksize + 4, 3, co.co_code, co.co_consts, co.co_names, co.co_varnames, co.co_filename, co.co_name, co.co_firstlineno, co.co_lnotab, co.co_freevars, tuple(co.co_cellvars + ('dummy',)))
        self.func = type(self.func)(codeobj, self.func.func_globals, self.func.func_name, self.func.func_defaults,self.func.func_closure)
        return self.func.func_code.co_flags

 

    def add_constant(self, const):
        """
        Adds a constant to the list used in the func. 
        Does not add if already there
        Returns the offset of the constant. 
        """
        co = self.func.func_code
        consts = list(co.co_consts)
        if const in co.co_consts: return consts.index(const) 
        consts.append(const)
        codeobj = type(co)(co.co_argcount, co.co_nlocals, co.co_stacksize + 4, co.co_flags, co.co_code, tuple(consts), co.co_names, co.co_varnames, co.co_filename, co.co_name, co.co_firstlineno, co.co_lnotab, co.co_freevars, co.co_cellvars)
        self.func = type(self.func)(codeobj, self.func.func_globals, self.func.func_name, self.func.func_defaults,self.func.func_closure)
        return consts.index(const) 

    def get_name(self, index):
        """
        Returns a name used by the function
        """
        return self.func.func_code.co_names[index]

    def add_name(self, name):
        """
        Adds a name to the list used in the func. 
        Does not add if already there
        Returns the offset of the name. 
        """
        co = self.func.func_code
        names = list(co.co_names)
        if name in names: return names.index(name) 
        names.append(name)
        codeobj = type(co)(co.co_argcount, co.co_nlocals, co.co_stacksize, co.co_flags, co.co_code, co.co_consts, tuple(names), co.co_varnames, co.co_filename, co.co_name, co.co_firstlineno, co.co_lnotab, co.co_freevars, co.co_cellvars)
        self.func = type(self.func)(codeobj, self.func.func_globals, self.func.func_name, self.func.func_defaults,self.func.func_closure)
        return names.index(name) 

    def get_varname(self, index):
        """
        Returns a variable name used by the function
        """
        return self.func.func_code.co_varnames[index]

    def add_varname(self, varname):
        """
        Adds a varname to the list used in the func. 
        Does not add if already there
        Returns the offset of the varname. 
        """
        self.add_name(varname)
        co = self.func.func_code
        varnames = list(co.co_varnames)
        if varname in varnames: return varnames.index(varname)
        varnames.append(varname)
        codeobj = type(co)(co.co_argcount, len(varnames) , co.co_stacksize + 10, co.co_flags, co.co_code, co.co_consts, co.co_names,tuple(varnames), co.co_filename, co.co_name, co.co_firstlineno, co.co_lnotab, co.co_freevars, co.co_cellvars)
        self.func = type(self.func)(codeobj, self.func.func_globals, self.func.func_name, self.func.func_defaults,self.func.func_closure)
        return varnames.index(varname)


    def get_cellvar(self, index):
        """
        Returns a closure variable name used by the function
        """
        return self.func.func_code.co_cellvars[index]

    def add_cellvar(self, varname):
        """
        Adds a closure varname to the list used in the func. 
        Does not add if already there
        Returns the offset of the varname. 
        """
        co = self.func.func_code
        cellvars = list(co.co_cellvars)
        if varname in cellvars: return cellvars.index(varname)
        cellvars.append(varname)
        codeobj = type(co)(co.co_argcount,  co.co_nlocals , co.co_stacksize + 10, co.co_flags, co.co_code, co.co_consts, co.co_names, co.co_varnames, co.co_filename, co.co_name, co.co_firstlineno, co.co_lnotab, co.co_freevars, tuple(cellvars))
        self.func = type(self.func)(codeobj, self.func.func_globals, self.func.func_name, self.func.func_defaults,self.func.func_closure)
        return cellvars.index(varname)

    def _assemble(self):
        """
        Re-assemble the function from an Oplist. Replaces the code section
        """
        lst = self.m_op_list.assemble()
        self._set_new_asm(''.join(map(chr, lst)))

    def _set_new_asm(self , asm):
        """    
        Set a new code section to the function
        """
        co = self.func.func_code
        codeobj = type(co)(co.co_argcount, co.co_nlocals, co.co_stacksize , co.co_flags, asm, co.co_consts, co.co_names, co.co_varnames, co.co_filename, co.co_name, co.co_firstlineno, co.co_lnotab, co.co_freevars, co.co_cellvars)
        self.func = type(self.func)(codeobj, self.func.func_globals, self.func.func_name, self.func.func_defaults,self.func.func_closure)

    def get_oplist(self):
        """
        Create a list of opcodes from the function. Returns an Oplist object
        """
        return self.m_op_list

    def set_oplist(self,oplist):
        self.m_op_list = oplist

    def get_func(self):
        self._assemble()
        return self.func

def myDis(func, logfilename=None):
    """
    printable disassembler, returns strings. great for diff
    """
    opstr = Function(func).get_oplist().disassemble()
    if logfilename<>None: open(logfilename,"wb").write(opstr)
    return opstr
