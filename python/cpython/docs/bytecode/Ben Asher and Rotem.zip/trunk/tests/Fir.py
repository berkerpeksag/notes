#!/usr/bin/python2.4

# some code from http://dspguru.com/sw/lib/fir_algs_1-0.c

def clear(z):
	ntaps = len(z)
	for ii in xrange(ntaps):
		z[ii] = 0

#SAMPLE fir_basic(SAMPLE input, int ntaps, const SAMPLE h[], SAMPLE z[]):
def fir_basic(input, h, z):
	"""
	fir_basic: Does the basic FIR algorithm: store input sample, calculate
	output sample, move delay line
	"""
	
	ntaps = len(z)
	#/* store input at the beginning of the delay line */
	z[0] = input
		
	#/* calc FIR */
	accum = 0
	for ii in xrange(ntaps):
		accum += h[ii] * z[ii]


	ntaps += -1
	z.reverse()
		
	for ii in xrange(ntaps):
		z[ii] = z[ii + 1]

		
	z.reverse()

	return accum;


