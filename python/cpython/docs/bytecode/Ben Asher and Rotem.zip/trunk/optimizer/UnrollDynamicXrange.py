#!/usr/bin/python2.4

# Unrolling of xrange and range functions

import logging
from Opcode import  *
from Function import  *

range_funcs = ['xrange','range']

def add_offset_to_induction_variable(Func, oplist,induction_index,const):
    i = 0
    while (i<len(oplist)):
        if oplist[i].name()=='LOAD_FAST':
            if oplist[i].m_arg == induction_index:
                oplist.insert_opcode(i+1, LoadConstOpcode.from_const(Func,1))
                oplist.insert_opcode(i+2, Opcode.default(Func,'INPLACE_ADD'))
        i+=1



# find the first "xrange(10)" function form in the bytecode
def find_first_xrange1(func, start = 0):
    ops = func.get_oplist()
    t = start
    while(1):
        t = ops.search_opcode_list(['SETUP_LOOP','LOAD_GLOBAL','LOAD_FAST','CALL_FUNCTION'], t)
        if (ops[t+1].m_arg in range_funcs):
            if ops[t+3].m_arg == 1:
                return t        
        t+=1
    raise OpcodeNotFoundException("xrange not found")
    

# open an xrange with one param to a 3-paramed xrange
def open_first_xrange_args(Func):
    ops = Func.get_oplist()
    try:
        loop_target = find_first_xrange1(Func,0)
    except OpcodeNotFoundException:
        return Func
    logging.debug("expanding xrange loop to 3 parameters")

    # fix the param that tells xrange that it has 3 arguments
    ops[loop_target+3].m_arg += 2
    ops.insert_opcode(loop_target+2, LoadConstOpcode.from_const(Func,0))
    ops.insert_opcode(loop_target+4, LoadConstOpcode.from_const(Func,1))

    Func.set_oplist(ops)
    return Func 

def open_xrange_args(func, times = 10):        
    for i in xrange(times):
        open_first_xrange_args(func)
    return func

# locate an xrange loop with 3 params
def find_first_unrolled_xrange3(func, start = 0):
    ops = func.get_oplist()
    t = start
    while(True):
        t = ops.search_opcode_list(['SETUP_LOOP','LOAD_GLOBAL','LOAD_CONST','LOAD_FAST','LOAD_CONST','CALL_FUNCTION','GET_ITER','TAG','FOR_ITER'], t)
        if ops[t+1].m_arg in range_funcs:
            if ops[t+5].m_arg == 3: #param number
                if ops[t+4].m_arg == 1: # step param
                    return t
        t+=1
    #raise OpcodeNotFoundException("loop not found")

def unroll_xrange(func, unroll_num= 2):
    loop_target = 0
    try:
        # places where xrange is used
        while (1):
            loop_target = find_first_unrolled_xrange3(func,loop_target)
            unroll_xrange_from_given_loop(func, unroll_num, loop_target)
            loop_target += 1
    except OpcodeNotFoundException:
            return func

def unroll_xrange_from_given_loop(func, unroll_num, loop_target):
    ops = func.get_oplist()
    logging.debug("unrolling xrange loop at " +str(loop_target) + " - " + str(unroll_num)+"times")

    # xrange(?,X,?)
    param_name = ops[loop_target+3].m_arg
    for_iter = ops[loop_target+8]
    first_store = ops[loop_target+9]

    # where the actual code starts
    loop_base_index = loop_target+10

    #setup loop jump to num, xrange(?,?,num) 
    ops[loop_target+4].m_arg = ops[loop_target+4].m_arg * unroll_num

    mark_oplist = Oplist()

    """
             12 LOAD_FAST                1 (param)
             15 LOAD_FAST                1 (param)
             18 LOAD_FAST                0 (a)
             21 BINARY_DIVIDE       
             22 BINARY_SUBTRACT     
             23 STORE_FAST               2 (mark)
    """
    
    mark_oplist.append_opcode(FastOpcode.from_load_fast(func,param_name))
    mark_oplist.append_opcode(LoadConstOpcode.from_const(func,unroll_num))
    mark_oplist.append_opcode(Opcode(func,int_from_op_name('BINARY_MODULO')))
    mark_oplist.append_opcode(FastOpcode.from_load_fast(func,param_name))
    mark_oplist.append_opcode(Opcode(func,int_from_op_name('BINARY_SUBTRACT')))
    mark_oplist.append_opcode(FastOpcode.from_store_fast(func,'mark'))
    mark_oplist.append_opcode(FastOpcode.from_load_fast(func,'mark'))
    mark_oplist.append_opcode(LoadConstOpcode.from_const(func,-1))
    mark_oplist.append_opcode(Opcode(func,int_from_op_name('BINARY_ADD')))
    mark_oplist.append_opcode(FastOpcode.from_store_fast(func,'mark_1'))

    #print  "\n",mark_oplist.disassemble()
    
    #count loop body size - replace with index(for_iter.m_arg) !!
    count = 0
    while (ops[count + loop_base_index] != for_iter.m_arg):
        #print ops[count + loop_base_index] ,  "--", for_iter.m_arg
        count += 1
    
    # get the loop body from the code
    loop_tail_code = ops.copy_slice(loop_target,count-1 + 14)

    # go step by step
    loop_tail_code[2] = FastOpcode.from_load_fast(func,'mark')
    loop_tail_code[3] = FastOpcode.from_load_fast(func,param_name)
    loop_tail_code[4].m_arg = 1
    loop_tail_code.adjust_addresses()
    #print "tail:\n",loop_tail_code.disassemble()

    # mark = x - (x%unroll)
    # xrange(?,mark-1,?)
    ops[loop_target+3] = FastOpcode.from_load_fast(func,'mark_1') 
    

    # get the loop body from the code
    body = ops.copy_slice(loop_target+10,count-1)
        
    #print "body==\n", body.disassemble()    

    # find induction index from STORE opcode (typically "i")
    induction_index = first_store.m_arg

    #print "dumping old body"
    # remove old code
    ops.del_opcode(loop_base_index,len(body))

    # construct the new body
    unrolled_body = Oplist()

    #print "constructing body"
    # for each time we unroll
    for i in xrange(unroll_num):
        unrolled_body.insert_oplist(len(unrolled_body),body)
        # turn induction variable in this iteration to the correct value
        add_offset_to_induction_variable(func, body,induction_index,1)

    # insert the new body
    ops.insert_oplist(loop_base_index,unrolled_body)

    # construct the tail of the loop    
    end_of_loop = loop_base_index + len(unrolled_body) + 2

    # insert original loop body here
    ops.insert_oplist(end_of_loop,loop_tail_code)

    # insert mark code at the beginning
    ops.insert_oplist(loop_target,mark_oplist)

    ops.adjust_addresses()
    #print ops.disassemble()

    func.set_oplist(ops)
    return func


