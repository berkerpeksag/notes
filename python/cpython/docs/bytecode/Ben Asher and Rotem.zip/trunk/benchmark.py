#!/usr/bin/python2.4

import time
from optimizer import *
from tests import *
import new
import dis
import sys

import random
import logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s %(levelname)s %(message)s', filename='/tmp/pykangaroo.log', filemode='w')

console = logging.StreamHandler()
console.setLevel(logging.INFO)
# set a format which is simpler for console use
formatter = logging.Formatter('%(message)s')
# tell the handler to use this format
console.setFormatter(formatter)
# add the handler to the root logger
logging.getLogger('').addHandler(console)


def benchmark_pypy_md5():
    import new

    message = map(chr,range(255)*1000)

    m2 = pymd5.md5()
    t1 = time.time()    # start
    m2.update(message)
    d2 = m2.digest()
    d1h = m2.hexdigest()
    t2 = time.time() # stop
    t_one = t2-t1
    m2 = pymd5.md5()


    # Optimize in here
    pymd5.XX = functionInline(pymd5.XX,pymd5._rotateLeft)
    functionOptimize(pymd5.XX,NumericOptimize)
    methodInline(m2._transform,pymd5.XX)
    methodOptimize(m2._transform,NumericOptimize)
    #done

    t1 = time.time() # start
    m2.update(message)
    d2 = m2.digest()
    d2h = m2.hexdigest()
    t2 = time.time() # stop
    t_two = t2-t1

    if (d1h <> d2h): logging.warn( "hash = " + str(d1h) + " != " + str(d2h))
    logging.info( "pypy md5 test - > Before: "+str(t_one) +" After: " + str(t_two) +  "| ratio: " + str(t_one/t_two))


def benchmark_rsa_md5():
    import new
    message = str(map(chr,range(255)*500))

    m2 = rsamd5.md5()
    t1 = time.time()    # start
    m2.update(message)
    d1 = m2.digest()
    t2 = time.time() # stop
    t_one = t2-t1
    m2 = rsamd5.md5()


    #Optimize in here:
    rsamd5.FF = functionInline(rsamd5.FF,rsamd5.F)
    rsamd5.GG = functionInline(rsamd5.GG,rsamd5.G)
    rsamd5.HH = functionInline(rsamd5.HH,rsamd5.H)
    rsamd5.II = functionInline(rsamd5.II,rsamd5.I)

    rsamd5.FF = functionInline(rsamd5.FF,rsamd5.ROTATE_LEFT)
    rsamd5.GG = functionInline(rsamd5.GG,rsamd5.ROTATE_LEFT)
    rsamd5.HH = functionInline(rsamd5.HH,rsamd5.ROTATE_LEFT)
    rsamd5.II = functionInline(rsamd5.II,rsamd5.ROTATE_LEFT)

    rsamd5.FF = functionOptimize(rsamd5.FF, NumericOptimize)
    rsamd5.GG = functionOptimize(rsamd5.GG, NumericOptimize)
    rsamd5.HH = functionOptimize(rsamd5.HH, NumericOptimize)
    rsamd5.II = functionOptimize(rsamd5.II, NumericOptimize)

    methodInline(m2.transform,rsamd5.FF)
    methodInline(m2.transform,rsamd5.GG)
    methodInline(m2.transform,rsamd5.HH)
    methodInline(m2.transform,rsamd5.II)
    methodInline(m2.transform,rsamd5.ROTATE_LEFT)

    #methodOptimize(m2.transform, NumericOptimize)
    # done

    t1 = time.time() # start
    m2.update(message)
    d2 = m2.digest()
    t2 = time.time() # stop
    t_two = t2-t1

    logging.debug( "hash = " + str(d1) +"=="+ str(d2))
    logging.info( "RSA md5 test -> Before:" + str(t_one) + " After:" + str(t_two) + "| ratio: " + str(t_one/t_two))



def benchmark_pypy_sha():
    import new

    message = map(chr,range(255)*5000)
 
    m2 = pysha.sha()
    t1 = time.time()    # start
    m2.update(message)
    d2 = m2.digest()
    d1h = m2.hexdigest()
    t2 = time.time() # stop
    t_one = t2-t1

    m2 = pysha.sha()

    #optimize here:
    methodInline(m2._transform, pysha._rotateLeft)
    methodOptimize(m2._transform, NumericOptimize)
    methodOptimize(m2._transform, Passes.cache_global_calls)
    #done

    t1 = time.time() # start
    m2.update(message)
    d2 = m2.digest()
    d2h = m2.hexdigest()
    t2 = time.time() # stop
    t_two = t2-t1

    if (d1h <> d2h): logging.warn( "hash = " + str(d1h) + " != " + str(d2h))
    logging.info( "pypy sha test-> Before:" + str(t_one)+ " After: " + str(t_two) +  "| ratio: " + str(t_one/t_two))


def benchmark_pystone():
    import new


    t1 = time.time()    # start
    pystone.main(50000)
    t2 = time.time() # stop
    t_one = t2-t1

    #pystone.Func2 = PrepareOptimize(pystone.Func2)

    # Inline all functions into one function

    pystone.Func2 = functionInline(pystone.Func2 ,pystone.Func1)
    pystone.Proc3 = functionInline(pystone.Proc3 ,pystone.Proc7)
    pystone.Proc6 = functionInline(pystone.Proc6 ,pystone.Func3)
    pystone.Proc6 = functionInline(pystone.Proc6 ,pystone.Proc3)

    pystone.Proc1 = functionInline(pystone.Proc1 ,pystone.Proc6)
    pystone.Proc1 = functionInline(pystone.Proc1 ,pystone.Proc7)
    pystone.Proc1 = functionInline(pystone.Proc1 ,pystone.Proc3)

    pystone.Proc0 = functionInline(pystone.Proc0 ,pystone.Func1)

    pystone.Proc0 = functionInline(pystone.Proc0 ,pystone.Func2)
    pystone.Proc0 = functionInline(pystone.Proc0 ,pystone.Proc4)
    pystone.Proc0 = functionInline(pystone.Proc0 ,pystone.Proc5)
    pystone.Proc0 = functionInline(pystone.Proc0 ,pystone.Proc7)

    #pystone.Proc0 = functionInline(pystone.Proc0 ,pystone.Proc1)
    pystone.Proc0 = functionInline(pystone.Proc0 ,pystone.Proc6)
    pystone.Proc0 = functionInline(pystone.Proc0 ,pystone.Proc2)
    pystone.Proc0 = functionInline(pystone.Proc0 ,pystone.Proc8)

    functionOptimize(pystone.Proc0,Passes.cache_global_calls)
    #pystone.Proc0 = Passes.cache_global_calls(pystone.Proc0)

    t1 = time.time() # start
    pystone.main(50000)
    t2 = time.time() # stop
    t_two = t2-t1
    logging.info( "pystone test-> Before:" + str(t_one)  + " After:" + str(t_two) +  "| ratio: " + str(t_one/t_two))




def benchmark_rijndael():
    import crypto
    import crypto.errors
    import crypto.cipher
    import crypto.cipher.base
    import crypto.cipher.rijndael
    import crypto.cipher.rijndael as rijndael
    from crypto.cipher.rijndael import Rijndael
    from crypto.cipher.base     import noPadding
    from binascii               import a2b_hex

    key = '2b7e151628aed2a6abf7158809cf4f3c'
    ct  = '3243f6a8885a308d313198a2e0370734'

    bkey, cipherText = a2b_hex(key), a2b_hex(ct)
    plainText = ''.join(map(str,range(100)*4000))
    kSize = len(bkey)
    bSize = len(cipherText) # set block size to length of block

    alg = Rijndael(bkey, keySize=kSize, blockSize=bSize, padding=noPadding())

    t1 = time.time() # start
    v1 = alg.encrypt(plainText)
    t2 = time.time() # stop
    t_one = t2-t1

    alg = Rijndael(bkey, keySize=kSize, blockSize=bSize, padding=noPadding())


    #optimize:
    crypto.cipher.rijndael.MixColumns = functionInline(crypto.cipher.rijndael.MixColumns,crypto.cipher.rijndael.mul)
    crypto.cipher.rijndael.InvMixColumns = functionInline(crypto.cipher.rijndael.InvMixColumns,crypto.cipher.rijndael.mul)

    crypto.cipher.rijndael.MixColumns = functionOptimize(crypto.cipher.rijndael.MixColumns,NumericOptimize)
    crypto.cipher.rijndael.InvMixColumns = functionOptimize(crypto.cipher.rijndael.InvMixColumns,NumericOptimize)

    functionOptimize(crypto.cipher.rijndael.InvMixColumns,  UnrollXrange.open_xrange_args)
    functionOptimize(crypto.cipher.rijndael.InvSubBytes,  UnrollXrange.open_xrange_args)
    functionOptimize(crypto.cipher.rijndael.MixColumns,  UnrollXrange.open_xrange_args)
    functionOptimize(crypto.cipher.rijndael.SubBytes,  UnrollXrange.open_xrange_args)

    functionOptimize(crypto.cipher.rijndael.InvMixColumns, UnrollXrange.unroll_xrange)
    functionOptimize(crypto.cipher.rijndael.InvSubBytes, UnrollXrange.unroll_xrange)
    functionOptimize(crypto.cipher.rijndael.MixColumns, UnrollXrange.unroll_xrange)
    functionOptimize(crypto.cipher.rijndael.SubBytes, UnrollXrange.unroll_xrange)

    methodInline(alg.encryptBlock,rijndael.SubBytes)
    methodInline(alg.encryptBlock,rijndael.ShiftRows)
    methodInline(alg.encryptBlock,rijndael.MixColumns)
    methodOptimize(alg.encryptBlock,NumericOptimize)
    #done

    t1 = time.time() # start
    v2 = alg.encrypt(plainText)
    t2 = time.time() # stop
    t_two = t2-t1

    if (v1!=v2): logging.info("ENCRYPT ERROR")
    logging.info( "crypto.rijndael test-> Before:" + str(t_one) + " After:" +str(t_two) +  "| ratio: " + str(t_one/t_two))

def optimize_and_test_micro_method(aFunc):

    aFunc2 = functionOptimize(aFunc,NumericOptimize)

    t1 = time.time()
    aFunc()
    t2 = time.time()
    t_one = t2-t1

    t1 = time.time()
    aFunc2()
    t2 = time.time()
    t_two = t2-t1

    logging.info( 'micro.' + str(aFunc.__doc__) + " -> Before: " + str(t_one) + " After:" + str(t_two))

def benchmark_micro_tests():
    methods = []
    methods.append(Benchmark.func_0)
    methods.append(Benchmark.func_1)
    methods.append(Benchmark.func_2)
    methods.append(Benchmark.func_3)
    methods.append(Benchmark.func_4)
    methods.append(Benchmark.func_5)
    methods.append(Benchmark.func_6)
    methods.append(Benchmark.func_7)
    methods.append(Benchmark.func_8)
    methods.append(Benchmark.func_10)
    methods.append(Benchmark.func_11)
    methods.append(Benchmark.func_12)
    methods.append(Benchmark.func_13)
    methods.append(Benchmark.func_14)
    methods.append(Benchmark.func_15)
    methods.append(Benchmark.func_16)
    methods.append(Benchmark.func_17)

    for method in methods:
        optimize_and_test_micro_method(method)




benchmark_pystone()
benchmark_pypy_md5()
benchmark_rsa_md5()
benchmark_pypy_sha()
benchmark_rijndael()
#benchmark_micro_tests()

