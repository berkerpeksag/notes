
THREADNUM = 10

import threading

class Runner(threading.Thread):

    def __init__(self, func, range_tup):
        threading. Thread.__init__(self)
        self.func = func
        self.range_tup = range_tup

    def run(self):
        print self.func
        self.func(self.range_tup[0],self.range_tup[1])

    def starter(func,threads_num, iterations):
        thds = []
        for i in xrange(threads_num):
            thds.append(Runner(func, (((i*iterations)/threads_num), (((i+1)*iterations)/threads_num))))
        for th in thds: th.start()
        for th in thds: th.join()
    starter = staticmethod(starter)


def sum_two_vectors(a, b , c):
    Z = 5
    for i in xrange(len(c)):
        c[i] = a[i] + b[i] + Z
    T = 9



def sum_two_vectors2(a,b,c):
    def helper(i_range_start, i_range_end ):
        for i in xrange(i_range_start, i_range_end):
            print i

    Runner.starter(helper, 17, 70)

sum_two_vectors2([],[],[])


def x_demo(param1):
        print param1
        Z = 42
        def foo(param2):
            print param2
            print Z
            FOO = "123"
            return param2
        AFTER = 1

import dis
dis.dis(x_demo)
print "\n\n\n"
dis.dis(x_demo.func_code.co_consts[-2])
print dir(x_demo.func_code)
print x_demo.func_code.co_cellvars 
print x_demo.func_code.co_freevars 
#sum_two_vectors(range(10),[],[])
