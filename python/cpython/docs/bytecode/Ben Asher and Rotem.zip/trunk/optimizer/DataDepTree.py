#!/usr/bin/python2.4

#In this file we implement the optimizations on the DataDependencyTree which are not the *simple* passes


from Opcode import  *
from Function import  *
from DataDepPasses import *
import logging



def optimize(data_dep_tree, passes):
        for i in xrange(10):
            active = False
            for optimize_pass in passes:
                for tree in data_dep_tree.m_trees:
                    active|= tree.accept(optimize_pass)

            #active |= constant_inline(data_dep_tree, 'STORE_FAST'   ,'LOAD_FAST','LOAD_FAST')
            #active |= constant_inline(data_dep_tree, 'STORE_GLOBAL' ,'LOAD_GLOBAL','LOAD_FAST')
            active |= constant_inline(data_dep_tree, 'STORE_FAST'   ,'LOAD_FAST','LOAD_CONST')
            active |= constant_inline(data_dep_tree, 'STORE_GLOBAL' ,'LOAD_GLOBAL','LOAD_CONST')
            active |= constant_waw_inline(data_dep_tree, 'STORE_GLOBAL' ,'LOAD_GLOBAL') # not cache coherent
            active |= constant_waw_inline(data_dep_tree, 'STORE_FAST' ,'LOAD_FAST')
            active |= remove_multiple_load_store(data_dep_tree)
            active |= remove_dead_code_expressions(data_dep_tree)
            active |= remove_stores_that_no_one_uses(data_dep_tree)

            if active == False: break

def constant_inline(data_dep_tree, store_tag,load_tag, subexp_load_type):
        """
        Insert constant/global assignment to all loads that come
         after the store and before next store
        """
        i = 0
        ret = False
        # for each tree , except for the last one
        while i < len(data_dep_tree.m_trees)-1:
            if (data_dep_tree.m_trees[i].m_op.name() == store_tag) and (data_dep_tree.m_trees[i].m_deps[0].m_op.name() == subexp_load_type):
                var = data_dep_tree.m_trees[i].m_op.m_arg
                load = data_dep_tree.m_trees[i].m_deps[0] 
                j = i+1
                while (j<len(data_dep_tree.m_trees)):
                    if data_dep_tree.m_trees[j].m_op.name() == 'TAG': break # loops are bad for us

                    # another store that steps on our variable -> break!
                    if data_dep_tree.m_trees[j].m_op.name() == store_tag and var == data_dep_tree.m_trees[j].m_op.m_arg: break

                    searcher = SearchOpcodeVisitor(load_tag,var)
                    data_dep_tree.m_trees[j].accept(searcher)
                    if len(searcher.m_match)>0:
                        src = searcher.m_match[0] # the load_fast opcode that was found
                        dst = load # the opcodes that 'store_fast' depends on
                        replacer = ReplaceOpcodeVisitor(src,dst)
                        data_dep_tree.m_trees[j].accept(replacer)
                        logging.debug("constant_inline:\n" + str(src) + "  ==> " + str(dst) + "\n times:" + str(replacer.count))
                        ret |= (replacer.count > 0)# return True if was able to replace the loaded opcode
                    j+=1
            i += 1
        return ret


#TODO: make sure to look for function calls, prints and global variable save
def constant_waw_inline(data_dep_tree, store_tag,load_tag):
        """
        Write after write elimination for simple expressions
        """
        ret = False
        i = 0
        # for each tree
        while i < len(data_dep_tree.m_trees):
            # simple store
            if data_dep_tree.m_trees[i].m_op.name() == store_tag:
                    var = data_dep_tree.m_trees[i].m_op.m_arg
                    load = data_dep_tree.m_trees[i].m_deps[0]

                    j = i+1
                    while (j<len(data_dep_tree.m_trees)):
                        searcher = SearchOpcodeVisitor(load_tag,var)
                        data_dep_tree.m_trees[j].accept(searcher)
                        if len(searcher.m_match)>0:
                            break # someone reads our value

                        # another store that steps on our variable
                        if data_dep_tree.m_trees[j].m_op.name() == store_tag and var == data_dep_tree.m_trees[j].m_op.m_arg:
                            #print "waw", str(data_dep_tree.m_trees[j])
                            logging.debug("constant_waw_inline: deleting:\n" + str(data_dep_tree.m_trees[j]))
                            del data_dep_tree.m_trees[j]
                            ret =  True
                        j+=1
            i += 1
        return ret


def remove_multiple_load_store(data_dep_tree):
        """
        This method removes the load after store dependancy. 
        insted of saving an object to a variable and than load it, 
        you insert it into the ast insted of the load command
        this way we save both the load and the save. Also the next passes 
        can optimize this code.

        """
        ret = False
        i = 0
        # for each tree , except for the last one
        while i < len(data_dep_tree.m_trees)-1:
            if data_dep_tree.m_trees[i].m_op.name() == 'STORE_FAST':
                param = data_dep_tree.m_trees[i].m_op.m_arg

                # if next tree is also a store tree for the same variable
                if data_dep_tree.m_trees[i+1].m_op.name() == 'STORE_FAST' and param == data_dep_tree.m_trees[i+1].m_op.m_arg:
                    # search for a single load_fast with the correct param
                    searcher = SearchOpcodeVisitor('LOAD_FAST',param)
                    data_dep_tree.m_trees[i+1].accept(searcher)
                    # if found 1 match only
                    if len(searcher.m_match) == 1:
                        #print "inserting tree as a branch"
                        src = searcher.m_match[0] # the load_fast opcode that was found
                        dst = data_dep_tree.m_trees[i].m_deps[0] # the opcodes that 'store_fast' depends on

                        logging.debug("WAW: inserting tree:\n" +str(dst) + "\n in place of\n " + str(src) + "\ninto tree:\n" + str(data_dep_tree.m_trees[i+1]))
                        replacer = ReplaceOpcodeVisitor(src,dst)
                        data_dep_tree.m_trees[i+1].accept(replacer)
                        del data_dep_tree.m_trees[i]
                        ret = True
                    if len(searcher.m_match) == 0:
                        #print "write after write"        
                        logging.debug("WAW: deleting:\n" + str(data_dep_tree.m_trees[i]) + "*" )
                        del data_dep_tree.m_trees[i]
                        ret = True
            i += 1
        return ret


def remove_dead_code_expressions(data_dep_tree):
        """
        This method removes dead code expressions such as "5+6". 
        It does not remove a function call that 
        does not save it's values. 
        """
        ret = False
        i = 0
        # for each tree , except for the last one
        while i < len(data_dep_tree.m_trees)-1:
            i += 1
            tree = data_dep_tree.m_trees[i]
            if tree.m_op.name() == 'POP_TOP':
                if len(tree.m_deps)==0: continue # stack is not balanced, continue
                if tree.m_deps[0].m_op.name() == 'CALL_FUNCTION': continue # we don't dump function calls
                if tree.m_deps[0].m_op.name() == 'TAG': continue # we don't dump function calls
                if tree.m_deps[0].m_op.name().startswith('JUMP_IF'): continue # we don't dump function calls

                logging.debug("remove_dead_code_expressions:\n" + str(data_dep_tree.m_trees[i]))
                del data_dep_tree.m_trees[i] # delete this tree, it's a pop branch!
                ret = True
        return ret


def remove_stores_that_no_one_uses(data_dep_tree):
        """
        remove store trees that do not have side effects and that the result is not being used
        """

        ret = False

        # collect 'store' values
        store_vars = {}
        for tree in data_dep_tree.m_trees:
            if tree.m_op.name() == 'STORE_FAST': store_vars[tree.m_op.m_arg] = True

        searcher = SearchOpcodeVisitor('LOAD_FAST',no_arg = True)
        for tree in data_dep_tree.m_trees:
            tree.accept(searcher)

        for op in searcher.m_match:
            if op.m_op.name() == 'LOAD_FAST' and op.m_op.m_arg in store_vars: del store_vars[op.m_op.m_arg]

        i = 0
        while i < len(data_dep_tree.m_trees)-1:
            i += 1
            if data_dep_tree.m_trees[i].m_op.name() == 'STORE_FAST' and data_dep_tree.m_trees[i].m_op.m_arg in store_vars:
                ret = True
                logging.debug("remove_stores_that_no_one_uses:\n" + str(data_dep_tree.m_trees[i]))
                del data_dep_tree.m_trees[i]
        return ret






