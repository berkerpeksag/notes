#!/usr/bin/python2.4

# Unrolling of xrange and range functions

import logging
from Opcode import  *
from Function import  *
from DataDepTree import *
from DataDepPasses import *

# find the first ...
def find_first_iterate_list(func, start = 0):
    ops = func.get_oplist()
    t = start
    return ops.search_opcode_list(['BUILD_LIST','GET_ITER','TAG','FOR_ITER','STORE_FAST'], t)
    

def unroll_list(func):
    loop_target = 0
    try:
        # places where xrange is used
        while (1):
            loop_target = find_first_iterate_list(func,loop_target)
            unroll_list_from_given_loop(func, loop_target)
            loop_target += 1
    except OpcodeNotFoundException:
        return func

def unroll_list_from_given_loop(func,loop_target):
    ops = func.get_oplist()

    unroll_num = ops[loop_target].m_arg
    logging.debug("unrolling list" + str(unroll_num) + "times")

    for_iter = ops[loop_target+3]

    # where the actual code starts
    loop_base_index = loop_target+3
    
    #count loop body size
    count = 0
    while (ops[count + loop_base_index] != for_iter.m_arg):
        #print ops[count + loop_base_index] ,  "--", for_iter.m_arg
        count += 1

    setup_start = loop_target
    while (ops[setup_start].name() != 'SETUP_LOOP'):
        #print ops[setup_start]
        setup_start -= 1

    consts = ops.copy_slice(setup_start+1,loop_target-setup_start-1)

    # get the loop body from the code
    body = ops.copy_slice(loop_target+4,count-2)
    
    setup_op = ops[setup_start]
    #return "sd"
    # remove the entire loop
    count = 0
    while (ops[count + setup_start] != setup_op.m_arg):
        #print ops[count + setup_start] ,  "--", setup_op.m_arg
        count += 1
    ops.del_opcode(setup_start,count+1)

    ddnl = DataDependencyNodeList(consts)    
    opl_new_unrolled_body = Oplist()

    #print str(ddnl)
    for tree in ddnl.m_trees:
        tree_opl = Oplist()
        tree.write(tree_opl)
        tree_opl.adjust_addresses()
        # add constnant load command
        opl_new_unrolled_body.append_oplist(tree_opl)
        # add original body
        opl_new_unrolled_body.append_oplist(body)
    
    ops.insert_oplist(setup_start,opl_new_unrolled_body)
    
    func.set_oplist(ops)
    return func


