#!/usr/bin/python2.4

# a set of tests for the code 

from optimizer import *
from Benchmark import *

class ComparisonFailedException(Exception): pass

def compare_results(res1, res2, testname, err_msg =""):
	if res1 != res2:
		print "error:\n", err_msg 
		raise ComparisonFailedException("Values differ " + str(res1) + ":" + str(res2) + " in " + testname)

def run_func(func, banner = None):
	if banner: print "Running", banner , func.__name__,
	else : print "Running %s" % func.__name__,
	result = func()
	print "Done"
	return result


def testUnrollCache(orig):
	result1 = run_func(orig)
	
	import random

	func = Function.Function(orig)
	oplist = func.get_oplist()
	func.func = open_xrange_args(func.func)
	func.func = unroll_xrange(func.func,random.randint(1,13))
	func.func = cache_global_calls(func.func)
	
	result2 = run_func(func.func)
	compare_results(result1,result2, "test unroll")

def testDDTLoadSave(orig):
	result1 = run_func(orig)
	
	import random

	func = Function.Function(orig)

	func.func = open_xrange_args(func.func)
	func.func = unroll_xrange(func.func,random.randint(1,13))
	func.func = cache_global_calls(func.func)	
	func.func = unroll_list(func.func)

	ddnl = DataDependencyNodeList(func.get_oplist())
	print "optimizing...",
	passes = [DeepAddJoinConstantVisitor(),\
			  JoinAddZeroVisitor(),\
			  JoinDoubleLoadVisitor(),\
			  LevelAddExpVisitor(),\
			  ConstMulExtractVisitor(),\
			  JoinDeepMultVisitor(),\
			  JoinAddSepMullMultVisitor(),\
			  JoinMullSepAddMultVisitor()]
	
	for i in xrange(2):
		# list of optimization passes to execute
		for optimize_pass in passes:
			for tree in ddnl.m_trees:
				tree.accept(optimize_pass)
				#tree.accept(SearchIDVisitor())
			func.assemble(ddnl.to_oplist())
			result2 = run_func(func.func,str(i)+":"+ str(optimize_pass).split()[0])
			compare_results(result1,result2, "test DDT load/save")
					
		ddnl.constant_inline('STORE_FAST'   ,'LOAD_FAST','LOAD_FAST')
		ddnl.constant_inline('STORE_GLOBAL' ,'LOAD_GLOBAL','LOAD_FAST')
		ddnl.constant_inline('STORE_FAST'   ,'LOAD_FAST','LOAD_CONST')
		ddnl.constant_inline('STORE_GLOBAL' ,'LOAD_GLOBAL','LOAD_CONST')
		ddnl.constant_waw_inline('STORE_GLOBAL' ,'LOAD_GLOBAL')		
		ddnl.constant_waw_inline('STORE_FAST' ,'LOAD_FAST')
		ddnl.remove_multiple_load_store()
		print "done passes"
	print "done"
	
	func.assemble(ddnl.to_oplist())
	result2 = run_func(func.func)
	compare_results(result1,result2, "test DDT load/save")

def testInline(major, minor):
	
	major_2 = inline_function(major,minor)
	result1 = run_func(major)
	result2 = run_func(major_2)
	compare_results(result1,result2, "test inline")

# a list of all functions to be tested
#all_func = [simple_1,simple_2,simple_3,loop_1,loop_2,loop_3,\
#	    loop_4,loop_5,loop_6,loop_7,loop_8,loop_9,loop_10,loop_11,\
#	    loop_12,foreach_1,foreach_2]

def testAll():
	for i in xrange(15):
		print "*"*10 + "pass " + str(i) + "*"*10
		for func in all_func:
			testUnrollCache(func)
			testDDTLoadSave(func)

	testInline(major_1,minor_1)
